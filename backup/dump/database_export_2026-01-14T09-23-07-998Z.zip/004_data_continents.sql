-- 004_data_continents.sql
-- Table Data for continents

INSERT INTO "public"."continents" ("id", "tenant_id", "name", "code_international", "code_national", "is_active", "created_at") VALUES ('361329eb-2879-4908-9895-fd3e3ae1e847', NULL, 'Africa', 'AF', NULL, TRUE, '2025-11-09T14:13:19.053944+00:00');
INSERT INTO "public"."continents" ("id", "tenant_id", "name", "code_international", "code_national", "is_active", "created_at") VALUES ('e69cdb62-130b-4945-bf3f-3aeaef96d78b', NULL, 'Asia', 'AS', NULL, TRUE, '2025-11-09T14:13:19.053944+00:00');
INSERT INTO "public"."continents" ("id", "tenant_id", "name", "code_international", "code_national", "is_active", "created_at") VALUES ('61b30c1f-4014-4ff1-8b74-d30866a8475e', NULL, 'Europe', 'EU', NULL, TRUE, '2025-11-09T14:13:19.053944+00:00');
INSERT INTO "public"."continents" ("id", "tenant_id", "name", "code_international", "code_national", "is_active", "created_at") VALUES ('8055955a-922b-46f2-8719-cff83b629ab2', NULL, 'North America', 'NA', NULL, TRUE, '2025-11-09T14:13:19.053944+00:00');
INSERT INTO "public"."continents" ("id", "tenant_id", "name", "code_international", "code_national", "is_active", "created_at") VALUES ('d7878e9e-e666-41d6-9226-11aac82d1264', NULL, 'South America', 'SA', NULL, TRUE, '2025-11-09T14:13:19.053944+00:00');
INSERT INTO "public"."continents" ("id", "tenant_id", "name", "code_international", "code_national", "is_active", "created_at") VALUES ('a3dcacc6-6460-46ae-9e3d-7ae7e3addbd6', NULL, 'Oceania', 'OC', NULL, TRUE, '2025-11-09T14:13:19.053944+00:00');
INSERT INTO "public"."continents" ("id", "tenant_id", "name", "code_international", "code_national", "is_active", "created_at") VALUES ('19ac3c2d-f92c-4a8f-8081-421f8cbe44a6', NULL, 'Antarctica', 'AN', NULL, TRUE, '2025-11-09T14:13:19.053944+00:00');
