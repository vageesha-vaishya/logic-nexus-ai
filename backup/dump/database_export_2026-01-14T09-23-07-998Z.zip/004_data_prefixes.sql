-- 004_data_prefixes.sql
-- Table Data for prefixes

INSERT INTO "storage"."prefixes" ("name", "level", "bucket_id", "created_at", "updated_at") VALUES ('ce4c64f5-cd8c-4d2d-bbbd-04972c4a7768', 1, 'db-backups', '2025-11-11T07:53:21.390576+00:00', '2025-11-11T07:53:21.390576+00:00');
INSERT INTO "storage"."prefixes" ("name", "level", "bucket_id", "created_at", "updated_at") VALUES ('ce4c64f5-cd8c-4d2d-bbbd-04972c4a7768/db-exports', 2, 'db-backups', '2025-11-11T07:53:21.390576+00:00', '2025-11-11T07:53:21.390576+00:00');
