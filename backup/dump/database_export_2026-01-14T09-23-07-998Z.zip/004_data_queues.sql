-- 004_data_queues.sql
-- Table Data for queues

INSERT INTO "public"."queues" ("id", "tenant_id", "name", "description", "email", "type", "is_active", "created_at", "updated_at") VALUES ('17c85d44-4d7c-4294-8f7c-2a6ea01298af', '9e2686ba-ef3c-42df-aea6-dcc880436b9f', 'Sk', '', '', 'round_robin', TRUE, '2026-01-06T03:12:46.855648+00:00', '2026-01-06T03:12:46.855648+00:00');
