-- 004_data_user_preferences.sql
-- Table Data for user_preferences

INSERT INTO "public"."user_preferences" ("id", "user_id", "tenant_id", "franchise_id", "admin_override_enabled", "theme", "language", "notifications_enabled", "created_at", "updated_at") VALUES ('288de07c-7e97-432c-827a-4effc1d4526d', 'ce4c64f5-cd8c-4d2d-bbbd-04972c4a7768', '37a4d9ca-626d-4ed3-9e71-5d416e7ccaf8', '18e1cd75-b4d5-4e1b-8472-c028829a18f8', FALSE, 'system', 'en', TRUE, '2026-01-10T04:51:58.553444+00:00', '2026-01-13T16:15:10.37856+00:00');
