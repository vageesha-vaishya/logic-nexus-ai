-- 004_data_charge_sides.sql
-- Table Data for charge_sides

INSERT INTO "public"."charge_sides" ("id", "name", "code", "description", "is_active", "created_at", "updated_at") VALUES ('dca4c9ff-f10b-4de5-afdf-d15afbad38d3', 'Buy', 'buy', 'Costs incurred from carriers/suppliers', TRUE, '2025-11-08T11:55:43.122485+00:00', '2025-11-08T11:55:43.122485+00:00');
INSERT INTO "public"."charge_sides" ("id", "name", "code", "description", "is_active", "created_at", "updated_at") VALUES ('0e065e06-1e00-4aa2-8f83-9223abe18a05', 'Sell', 'sell', 'Charges to customers', TRUE, '2025-11-08T11:55:43.122485+00:00', '2025-11-08T11:55:43.122485+00:00');
