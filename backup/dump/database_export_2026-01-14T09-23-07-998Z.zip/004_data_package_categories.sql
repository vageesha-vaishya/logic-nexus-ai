-- 004_data_package_categories.sql
-- Table Data for package_categories

INSERT INTO "public"."package_categories" ("id", "tenant_id", "category_name", "category_code") VALUES ('c0d110f5-f15a-42d5-84fb-c2372457896c', '9e2686ba-ef3c-42df-aea6-dcc880436b9f', 'Standard Container', 'STD');
INSERT INTO "public"."package_categories" ("id", "tenant_id", "category_name", "category_code") VALUES ('20e819ff-8d54-403f-a8b2-08f01ac0d49e', '9e2686ba-ef3c-42df-aea6-dcc880436b9f', 'Open Top Container', 'OT');
INSERT INTO "public"."package_categories" ("id", "tenant_id", "category_name", "category_code") VALUES ('fb0584d1-369b-4df1-b428-96576467cff2', '9e2686ba-ef3c-42df-aea6-dcc880436b9f', 'Flat Rack Container', 'FR');
INSERT INTO "public"."package_categories" ("id", "tenant_id", "category_name", "category_code") VALUES ('d2c1a5e7-0c3d-45fa-9656-6d39cf8be4f5', '9e2686ba-ef3c-42df-aea6-dcc880436b9f', 'Refrigerated Container', 'REEFER');
