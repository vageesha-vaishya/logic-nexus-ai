-- 002_tables.sql
-- Tables Schema (Structure Only, No Constraints)

CREATE TABLE IF NOT EXISTS "auth"."audit_log_entries" (
  "instance_id" uuid,
  "id" uuid NOT NULL,
  "payload" json,
  "created_at" timestamp with time zone,
  "ip_address" character varying NOT NULL DEFAULT ''::character varying
);

CREATE TABLE IF NOT EXISTS "auth"."flow_state" (
  "id" uuid NOT NULL,
  "user_id" uuid,
  "auth_code" text NOT NULL,
  "code_challenge_method" USER-DEFINED NOT NULL,
  "code_challenge" text NOT NULL,
  "provider_type" text NOT NULL,
  "provider_access_token" text,
  "provider_refresh_token" text,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone,
  "authentication_method" text NOT NULL,
  "auth_code_issued_at" timestamp with time zone
);

CREATE TABLE IF NOT EXISTS "auth"."identities" (
  "provider_id" text NOT NULL,
  "user_id" uuid NOT NULL,
  "identity_data" jsonb NOT NULL,
  "provider" text NOT NULL,
  "last_sign_in_at" timestamp with time zone,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone,
  "email" text,
  "id" uuid NOT NULL DEFAULT gen_random_uuid()
);

CREATE TABLE IF NOT EXISTS "auth"."instances" (
  "id" uuid NOT NULL,
  "uuid" uuid,
  "raw_base_config" text,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone
);

CREATE TABLE IF NOT EXISTS "auth"."mfa_amr_claims" (
  "session_id" uuid NOT NULL,
  "created_at" timestamp with time zone NOT NULL,
  "updated_at" timestamp with time zone NOT NULL,
  "authentication_method" text NOT NULL,
  "id" uuid NOT NULL
);

CREATE TABLE IF NOT EXISTS "auth"."mfa_challenges" (
  "id" uuid NOT NULL,
  "factor_id" uuid NOT NULL,
  "created_at" timestamp with time zone NOT NULL,
  "verified_at" timestamp with time zone,
  "ip_address" inet NOT NULL,
  "otp_code" text,
  "web_authn_session_data" jsonb
);

CREATE TABLE IF NOT EXISTS "auth"."mfa_factors" (
  "id" uuid NOT NULL,
  "user_id" uuid NOT NULL,
  "friendly_name" text,
  "factor_type" USER-DEFINED NOT NULL,
  "status" USER-DEFINED NOT NULL,
  "created_at" timestamp with time zone NOT NULL,
  "updated_at" timestamp with time zone NOT NULL,
  "secret" text,
  "phone" text,
  "last_challenged_at" timestamp with time zone,
  "web_authn_credential" jsonb,
  "web_authn_aaguid" uuid,
  "last_webauthn_challenge_data" jsonb
);

CREATE TABLE IF NOT EXISTS "auth"."oauth_authorizations" (
  "id" uuid NOT NULL,
  "authorization_id" text NOT NULL,
  "client_id" uuid NOT NULL,
  "user_id" uuid,
  "redirect_uri" text NOT NULL,
  "scope" text NOT NULL,
  "state" text,
  "resource" text,
  "code_challenge" text,
  "code_challenge_method" USER-DEFINED,
  "response_type" USER-DEFINED NOT NULL DEFAULT 'code'::auth.oauth_response_type,
  "status" USER-DEFINED NOT NULL DEFAULT 'pending'::auth.oauth_authorization_status,
  "authorization_code" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "expires_at" timestamp with time zone NOT NULL DEFAULT (now() + '00:03:00'::interval),
  "approved_at" timestamp with time zone,
  "nonce" text
);

CREATE TABLE IF NOT EXISTS "auth"."oauth_client_states" (
  "id" uuid NOT NULL,
  "provider_type" text NOT NULL,
  "code_verifier" text,
  "created_at" timestamp with time zone NOT NULL
);

CREATE TABLE IF NOT EXISTS "auth"."oauth_clients" (
  "id" uuid NOT NULL,
  "client_secret_hash" text,
  "registration_type" USER-DEFINED NOT NULL,
  "redirect_uris" text NOT NULL,
  "grant_types" text NOT NULL,
  "client_name" text,
  "client_uri" text,
  "logo_uri" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp with time zone NOT NULL DEFAULT now(),
  "deleted_at" timestamp with time zone,
  "client_type" USER-DEFINED NOT NULL DEFAULT 'confidential'::auth.oauth_client_type
);

CREATE TABLE IF NOT EXISTS "auth"."oauth_consents" (
  "id" uuid NOT NULL,
  "user_id" uuid NOT NULL,
  "client_id" uuid NOT NULL,
  "scopes" text NOT NULL,
  "granted_at" timestamp with time zone NOT NULL DEFAULT now(),
  "revoked_at" timestamp with time zone
);

CREATE TABLE IF NOT EXISTS "auth"."one_time_tokens" (
  "id" uuid NOT NULL,
  "user_id" uuid NOT NULL,
  "token_type" USER-DEFINED NOT NULL,
  "token_hash" text NOT NULL,
  "relates_to" text NOT NULL,
  "created_at" timestamp without time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp without time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "auth"."refresh_tokens" (
  "instance_id" uuid,
  "id" bigint NOT NULL DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass),
  "token" character varying,
  "user_id" character varying,
  "revoked" boolean,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone,
  "parent" character varying,
  "session_id" uuid
);

CREATE TABLE IF NOT EXISTS "auth"."saml_providers" (
  "id" uuid NOT NULL,
  "sso_provider_id" uuid NOT NULL,
  "entity_id" text NOT NULL,
  "metadata_xml" text NOT NULL,
  "metadata_url" text,
  "attribute_mapping" jsonb,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone,
  "name_id_format" text
);

CREATE TABLE IF NOT EXISTS "auth"."saml_relay_states" (
  "id" uuid NOT NULL,
  "sso_provider_id" uuid NOT NULL,
  "request_id" text NOT NULL,
  "for_email" text,
  "redirect_to" text,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone,
  "flow_state_id" uuid
);

CREATE TABLE IF NOT EXISTS "auth"."schema_migrations" (
  "version" character varying NOT NULL
);

CREATE TABLE IF NOT EXISTS "auth"."sessions" (
  "id" uuid NOT NULL,
  "user_id" uuid NOT NULL,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone,
  "factor_id" uuid,
  "aal" USER-DEFINED,
  "not_after" timestamp with time zone,
  "refreshed_at" timestamp without time zone,
  "user_agent" text,
  "ip" inet,
  "tag" text,
  "oauth_client_id" uuid,
  "refresh_token_hmac_key" text,
  "refresh_token_counter" bigint,
  "scopes" text
);

CREATE TABLE IF NOT EXISTS "auth"."sso_domains" (
  "id" uuid NOT NULL,
  "sso_provider_id" uuid NOT NULL,
  "domain" text NOT NULL,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone
);

CREATE TABLE IF NOT EXISTS "auth"."sso_providers" (
  "id" uuid NOT NULL,
  "resource_id" text,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone,
  "disabled" boolean
);

CREATE TABLE IF NOT EXISTS "auth"."users" (
  "instance_id" uuid,
  "id" uuid NOT NULL,
  "aud" character varying,
  "role" character varying,
  "email" character varying,
  "encrypted_password" character varying,
  "email_confirmed_at" timestamp with time zone,
  "invited_at" timestamp with time zone,
  "confirmation_token" character varying,
  "confirmation_sent_at" timestamp with time zone,
  "recovery_token" character varying,
  "recovery_sent_at" timestamp with time zone,
  "email_change_token_new" character varying,
  "email_change" character varying,
  "email_change_sent_at" timestamp with time zone,
  "last_sign_in_at" timestamp with time zone,
  "raw_app_meta_data" jsonb,
  "raw_user_meta_data" jsonb,
  "is_super_admin" boolean,
  "created_at" timestamp with time zone,
  "updated_at" timestamp with time zone,
  "phone" text DEFAULT NULL::character varying,
  "phone_confirmed_at" timestamp with time zone,
  "phone_change" text DEFAULT ''::character varying,
  "phone_change_token" character varying DEFAULT ''::character varying,
  "phone_change_sent_at" timestamp with time zone,
  "confirmed_at" timestamp with time zone,
  "email_change_token_current" character varying DEFAULT ''::character varying,
  "email_change_confirm_status" smallint DEFAULT 0,
  "banned_until" timestamp with time zone,
  "reauthentication_token" character varying DEFAULT ''::character varying,
  "reauthentication_sent_at" timestamp with time zone,
  "is_sso_user" boolean NOT NULL DEFAULT false,
  "deleted_at" timestamp with time zone,
  "is_anonymous" boolean NOT NULL DEFAULT false
);

CREATE TABLE IF NOT EXISTS "public"."accounts" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "franchise_id" uuid,
  "name" text NOT NULL,
  "account_type" USER-DEFINED DEFAULT 'prospect'::account_type,
  "status" USER-DEFINED DEFAULT 'active'::account_status,
  "industry" text,
  "website" text,
  "phone" text,
  "email" text,
  "billing_address" jsonb DEFAULT '{}'::jsonb,
  "shipping_address" jsonb DEFAULT '{}'::jsonb,
  "annual_revenue" numeric,
  "employee_count" integer,
  "description" text,
  "owner_id" uuid,
  "created_by" uuid,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "parent_account_id" uuid
);

CREATE TABLE IF NOT EXISTS "public"."activities" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "franchise_id" uuid,
  "activity_type" USER-DEFINED NOT NULL,
  "status" USER-DEFINED DEFAULT 'planned'::activity_status,
  "priority" USER-DEFINED DEFAULT 'medium'::priority_level,
  "subject" text NOT NULL,
  "description" text,
  "due_date" timestamp with time zone,
  "completed_at" timestamp with time zone,
  "account_id" uuid,
  "contact_id" uuid,
  "lead_id" uuid,
  "assigned_to" uuid,
  "created_by" uuid,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "custom_fields" jsonb DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS "public"."aes_hts_codes" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "hts_code" character varying NOT NULL,
  "schedule_b" character varying,
  "category" character varying NOT NULL,
  "sub_category" character varying,
  "sub_sub_category" character varying,
  "description" text NOT NULL,
  "duty_rate" character varying,
  "special_provisions" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp with time zone NOT NULL DEFAULT now(),
  "uom1" character varying,
  "uom2" character varying
);

CREATE TABLE IF NOT EXISTS "public"."audit_logs" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "user_id" uuid,
  "action" text NOT NULL,
  "resource_type" text NOT NULL,
  "resource_id" uuid,
  "details" jsonb DEFAULT '{}'::jsonb,
  "ip_address" text,
  "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."auth_permissions" (
  "id" text NOT NULL,
  "category" text NOT NULL,
  "description" text,
  "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."auth_role_permissions" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "role_id" text NOT NULL,
  "permission_id" text NOT NULL,
  "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."auth_roles" (
  "id" text NOT NULL,
  "label" text NOT NULL,
  "description" text,
  "level" integer NOT NULL DEFAULT 0,
  "can_manage_scopes" ARRAY DEFAULT '{}'::text[],
  "is_system" boolean DEFAULT false,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."cargo_details" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "service_type" text,
  "service_id" uuid,
  "cargo_type_id" uuid,
  "commodity_description" text,
  "hs_code" text,
  "weight_kg" numeric,
  "volume_cbm" numeric,
  "dimensions_cm" jsonb,
  "value_amount" numeric,
  "value_currency" text DEFAULT 'USD'::text,
  "special_requirements" text,
  "is_hazardous" boolean DEFAULT false,
  "hazmat_un_number" text,
  "hazmat_class" text,
  "temperature_controlled" boolean DEFAULT false,
  "temperature_range" jsonb,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "created_by" uuid,
  "notes" text,
  "actual_weight_kg" numeric,
  "volumetric_weight_kg" numeric,
  "chargeable_weight_kg" numeric
);

CREATE TABLE IF NOT EXISTS "public"."cargo_types" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "cargo_type_name" text NOT NULL,
  "cargo_code" text,
  "requires_special_handling" boolean DEFAULT false,
  "hazmat_class" text,
  "temperature_controlled" boolean DEFAULT false,
  "description" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."carrier_rate_charges" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "carrier_rate_id" uuid NOT NULL,
  "charge_type" text NOT NULL,
  "basis" text,
  "quantity" numeric DEFAULT 1,
  "amount" numeric NOT NULL,
  "currency" text DEFAULT 'USD'::text,
  "notes" text,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."carrier_rates" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "service_id" uuid,
  "carrier_name" text NOT NULL,
  "rate_type" text NOT NULL,
  "origin_location" text,
  "destination_location" text,
  "base_rate" numeric NOT NULL,
  "currency" text DEFAULT 'USD'::text,
  "valid_from" date NOT NULL,
  "valid_until" date,
  "weight_break_min" numeric,
  "weight_break_max" numeric,
  "surcharges" jsonb DEFAULT '[]'::jsonb,
  "accessorial_fees" jsonb DEFAULT '[]'::jsonb,
  "notes" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "carrier_id" uuid,
  "origin_port_id" uuid,
  "destination_port_id" uuid,
  "mode" text,
  "rate_reference_id" text,
  "status" text DEFAULT 'active'::text
);

CREATE TABLE IF NOT EXISTS "public"."carrier_service_types" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "carrier_id" uuid NOT NULL,
  "service_type" text NOT NULL,
  "code_type" text,
  "code_value" text,
  "is_primary" boolean DEFAULT false,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."carriers" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "carrier_name" text NOT NULL,
  "carrier_code" text,
  "carrier_type" text,
  "contact_person" text,
  "contact_email" text,
  "contact_phone" text,
  "address" jsonb DEFAULT '{}'::jsonb,
  "website" text,
  "service_routes" jsonb DEFAULT '[]'::jsonb,
  "rating" numeric,
  "is_active" boolean DEFAULT true,
  "notes" text,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "mode" text,
  "scac" text,
  "iata" text,
  "mc_dot" text
);

CREATE TABLE IF NOT EXISTS "public"."charge_bases" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "name" text NOT NULL,
  "code" text NOT NULL,
  "description" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."charge_categories" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "name" text NOT NULL,
  "code" text NOT NULL,
  "description" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."charge_sides" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "name" text NOT NULL,
  "code" text NOT NULL,
  "description" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."charge_tier_config" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "name" text NOT NULL,
  "description" text,
  "basis_id" uuid,
  "category_id" uuid,
  "service_type_id" uuid,
  "carrier_id" uuid,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."charge_tier_ranges" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tier_config_id" uuid NOT NULL,
  "min_value" numeric NOT NULL,
  "max_value" numeric,
  "rate" numeric NOT NULL,
  "currency_id" uuid,
  "sort_order" integer DEFAULT 1000,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."charge_weight_breaks" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "carrier_id" uuid,
  "service_type_id" uuid,
  "name" text NOT NULL,
  "description" text,
  "min_weight_kg" numeric NOT NULL,
  "max_weight_kg" numeric,
  "rate_per_kg" numeric NOT NULL,
  "currency_id" uuid,
  "effective_from" date NOT NULL DEFAULT CURRENT_DATE,
  "effective_until" date,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."cities" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid,
  "country_id" uuid,
  "state_id" uuid,
  "name" text NOT NULL,
  "code_national" text,
  "latitude" numeric,
  "longitude" numeric,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."compliance_checks" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "quote_id" uuid NOT NULL,
  "rule_id" uuid,
  "check_status" text NOT NULL,
  "check_details" jsonb,
  "checked_at" timestamp with time zone DEFAULT now(),
  "checked_by" uuid
);

CREATE TABLE IF NOT EXISTS "public"."compliance_rules" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "rule_name" text NOT NULL,
  "service_type" text,
  "regulation_agency" text,
  "rule_description" text,
  "validation_criteria" jsonb NOT NULL,
  "required_documents" jsonb DEFAULT '[]'::jsonb,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."consignees" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "company_name" text NOT NULL,
  "contact_person" text,
  "contact_email" text,
  "contact_phone" text,
  "address" jsonb DEFAULT '{}'::jsonb,
  "tax_id" text,
  "customs_id" text,
  "is_active" boolean DEFAULT true,
  "notes" text,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."contacts" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "franchise_id" uuid,
  "account_id" uuid,
  "first_name" text NOT NULL,
  "last_name" text NOT NULL,
  "title" text,
  "email" text,
  "phone" text,
  "mobile" text,
  "linkedin_url" text,
  "address" jsonb DEFAULT '{}'::jsonb,
  "is_primary" boolean DEFAULT false,
  "notes" text,
  "owner_id" uuid,
  "created_by" uuid,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."container_sizes" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid,
  "name" text NOT NULL,
  "code" text,
  "description" text,
  "length_ft" numeric,
  "width_ft" numeric,
  "height_ft" numeric,
  "max_weight_kg" numeric,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "has_ventilation" boolean DEFAULT false,
  "has_temperature_control" boolean DEFAULT false,
  "is_open_top" boolean DEFAULT false,
  "is_flat_rack" boolean DEFAULT false
);

CREATE TABLE IF NOT EXISTS "public"."container_types" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid,
  "name" text NOT NULL,
  "code" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "ownership_type" text,
  "is_special" boolean DEFAULT false,
  "special_type" text
);

CREATE TABLE IF NOT EXISTS "public"."continents" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid,
  "name" text NOT NULL,
  "code_international" text,
  "code_national" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."countries" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid,
  "continent_id" uuid,
  "name" text NOT NULL,
  "code_iso2" text,
  "code_iso3" text,
  "code_national" text,
  "phone_code" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."currencies" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "code" text NOT NULL,
  "name" text NOT NULL,
  "symbol" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."custom_role_permissions" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "role_id" uuid NOT NULL,
  "permission_key" text NOT NULL,
  "created_at" timestamp with time zone DEFAULT now(),
  "access_type" text NOT NULL DEFAULT 'grant'::text
);

CREATE TABLE IF NOT EXISTS "public"."custom_roles" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "name" text NOT NULL,
  "description" text,
  "is_active" boolean DEFAULT true,
  "is_system_role" boolean DEFAULT false,
  "created_by" uuid,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."customer_selections" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "quote_id" uuid NOT NULL,
  "quotation_version_id" uuid NOT NULL,
  "quotation_version_option_id" uuid NOT NULL,
  "reason" text,
  "selected_by" uuid,
  "selected_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."customs_documents" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "shipment_id" uuid NOT NULL,
  "document_type" text NOT NULL,
  "document_number" text,
  "issue_date" date,
  "expiry_date" date,
  "issuing_authority" text,
  "document_url" text,
  "status" text DEFAULT 'pending'::text,
  "notes" text,
  "created_by" uuid,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."dashboard_preferences" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "user_id" uuid NOT NULL,
  "tenant_id" uuid,
  "widgets" jsonb NOT NULL DEFAULT '[]'::jsonb,
  "layout" jsonb,
  "theme_overrides" jsonb,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."document_templates" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "template_name" text NOT NULL,
  "document_type" text NOT NULL,
  "service_type" text,
  "template_content" text NOT NULL,
  "required_fields" jsonb DEFAULT '[]'::jsonb,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."email_account_delegations" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "account_id" uuid NOT NULL,
  "delegate_user_id" uuid NOT NULL,
  "permissions" jsonb NOT NULL DEFAULT '["read"]'::jsonb,
  "granted_by" uuid,
  "granted_at" timestamp with time zone DEFAULT now(),
  "expires_at" timestamp with time zone,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."email_accounts" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "user_id" uuid NOT NULL,
  "tenant_id" uuid,
  "franchise_id" uuid,
  "provider" text NOT NULL,
  "email_address" text NOT NULL,
  "display_name" text,
  "is_primary" boolean DEFAULT false,
  "is_active" boolean DEFAULT true,
  "access_token" text,
  "refresh_token" text,
  "token_expires_at" timestamp with time zone,
  "smtp_host" text,
  "smtp_port" integer,
  "smtp_username" text,
  "smtp_password" text,
  "smtp_use_tls" boolean DEFAULT true,
  "imap_host" text,
  "imap_port" integer,
  "imap_username" text,
  "imap_password" text,
  "imap_use_ssl" boolean DEFAULT true,
  "last_sync_at" timestamp with time zone,
  "sync_frequency" integer DEFAULT 5,
  "auto_sync_enabled" boolean DEFAULT true,
  "settings" jsonb DEFAULT '{}'::jsonb,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."email_audit_log" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid,
  "franchise_id" uuid,
  "email_id" uuid,
  "scheduled_email_id" uuid,
  "event_type" text NOT NULL,
  "event_data" jsonb,
  "user_id" uuid,
  "ip_address" inet,
  "user_agent" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."email_filters" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "user_id" uuid NOT NULL,
  "tenant_id" uuid NOT NULL,
  "account_id" uuid,
  "name" text NOT NULL,
  "description" text,
  "priority" integer DEFAULT 0,
  "is_active" boolean DEFAULT true,
  "conditions" jsonb NOT NULL DEFAULT '[]'::jsonb,
  "actions" jsonb NOT NULL DEFAULT '[]'::jsonb,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."email_templates" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "franchise_id" uuid,
  "created_by" uuid,
  "name" text NOT NULL,
  "description" text,
  "subject" text NOT NULL,
  "body_html" text,
  "body_text" text,
  "variables" jsonb DEFAULT '[]'::jsonb,
  "category" text,
  "is_shared" boolean DEFAULT false,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."emails" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid,
  "franchise_id" uuid,
  "account_id" uuid NOT NULL,
  "message_id" text NOT NULL,
  "thread_id" text,
  "subject" text NOT NULL,
  "from_email" text NOT NULL,
  "from_name" text,
  "to_emails" jsonb NOT NULL DEFAULT '[]'::jsonb,
  "cc_emails" jsonb DEFAULT '[]'::jsonb,
  "bcc_emails" jsonb DEFAULT '[]'::jsonb,
  "reply_to" text,
  "body_text" text,
  "body_html" text,
  "snippet" text,
  "has_attachments" boolean DEFAULT false,
  "attachments" jsonb DEFAULT '[]'::jsonb,
  "direction" text NOT NULL,
  "status" text DEFAULT 'received'::text,
  "is_read" boolean DEFAULT false,
  "is_starred" boolean DEFAULT false,
  "is_archived" boolean DEFAULT false,
  "is_spam" boolean DEFAULT false,
  "is_deleted" boolean DEFAULT false,
  "folder" text DEFAULT 'inbox'::text,
  "labels" jsonb DEFAULT '[]'::jsonb,
  "category" text,
  "lead_id" uuid,
  "contact_id" uuid,
  "account_id_crm" uuid,
  "opportunity_id" uuid,
  "sent_at" timestamp with time zone,
  "received_at" timestamp with time zone DEFAULT now(),
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "priority" text DEFAULT 'normal'::text,
  "importance" text DEFAULT 'normal'::text,
  "in_reply_to" text,
  "email_references" ARRAY,
  "size_bytes" integer,
  "raw_headers" jsonb DEFAULT '{}'::jsonb,
  "conversation_id" text,
  "internet_message_id" text,
  "has_inline_images" boolean DEFAULT false,
  "sync_error" text,
  "last_sync_attempt" timestamp with time zone,
  "user_id" uuid,
  "ai_category" text,
  "ai_sentiment" text,
  "ai_urgency" text,
  "queue" text
);

CREATE TABLE IF NOT EXISTS "public"."entity_transfer_items" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "transfer_id" uuid NOT NULL,
  "entity_type" USER-DEFINED NOT NULL,
  "entity_id" uuid NOT NULL,
  "status" USER-DEFINED NOT NULL DEFAULT 'pending'::transfer_status,
  "error_message" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."entity_transfers" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "source_tenant_id" uuid NOT NULL,
  "source_franchise_id" uuid,
  "target_tenant_id" uuid NOT NULL,
  "target_franchise_id" uuid,
  "transfer_type" USER-DEFINED NOT NULL,
  "status" USER-DEFINED NOT NULL DEFAULT 'pending'::transfer_status,
  "requested_by" uuid NOT NULL,
  "approved_by" uuid,
  "rejection_reason" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "updated_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."franchises" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "name" text NOT NULL,
  "code" text NOT NULL,
  "address" jsonb DEFAULT '{}'::jsonb,
  "manager_id" uuid,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."fx_rates" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "from_currency_id" uuid NOT NULL,
  "to_currency_id" uuid NOT NULL,
  "rate" numeric NOT NULL,
  "effective_date" date NOT NULL,
  "source" text,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."import_errors" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "import_id" uuid NOT NULL,
  "row_number" integer,
  "field" text,
  "error_message" text,
  "raw_data" jsonb,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."import_history" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid,
  "entity_name" text NOT NULL,
  "table_name" text NOT NULL,
  "file_name" text NOT NULL,
  "imported_by" uuid,
  "imported_at" timestamp with time zone NOT NULL DEFAULT now(),
  "status" text NOT NULL DEFAULT 'partial'::text,
  "summary" jsonb DEFAULT '{}'::jsonb,
  "reverted_at" timestamp with time zone,
  "reverted_by" uuid,
  "created_at" timestamp with time zone NOT NULL DEFAULT now(),
  "completed_at" timestamp with time zone
);

CREATE TABLE IF NOT EXISTS "public"."import_history_details" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "import_id" uuid NOT NULL,
  "record_id" text NOT NULL,
  "operation_type" text NOT NULL,
  "previous_data" jsonb,
  "new_data" jsonb,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."incoterms" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "incoterm_code" text NOT NULL,
  "incoterm_name" text NOT NULL,
  "description" text,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."invitations" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "email" text NOT NULL,
  "role" USER-DEFINED NOT NULL,
  "tenant_id" uuid,
  "franchise_id" uuid,
  "invited_by" uuid NOT NULL,
  "token" text NOT NULL,
  "expires_at" timestamp with time zone NOT NULL,
  "accepted_at" timestamp with time zone,
  "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."lead_activities" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "lead_id" uuid NOT NULL,
  "type" text NOT NULL,
  "metadata" jsonb DEFAULT '{}'::jsonb,
  "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."lead_assignment_history" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "lead_id" uuid NOT NULL,
  "assigned_from" uuid,
  "assigned_to" uuid NOT NULL,
  "assignment_method" text NOT NULL,
  "rule_id" uuid,
  "reason" text,
  "assigned_at" timestamp with time zone DEFAULT now(),
  "assigned_by" uuid,
  "tenant_id" uuid NOT NULL,
  "franchise_id" uuid
);

CREATE TABLE IF NOT EXISTS "public"."lead_assignment_queue" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "lead_id" uuid NOT NULL,
  "tenant_id" uuid NOT NULL,
  "franchise_id" uuid,
  "priority" integer DEFAULT 0,
  "status" text DEFAULT 'pending'::text,
  "retry_count" integer DEFAULT 0,
  "error_message" text,
  "created_at" timestamp with time zone DEFAULT now(),
  "processed_at" timestamp with time zone
);

CREATE TABLE IF NOT EXISTS "public"."lead_assignment_rules" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "rule_name" text NOT NULL,
  "priority" integer DEFAULT 0,
  "criteria" jsonb NOT NULL,
  "assigned_to" uuid,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "assignment_type" text DEFAULT 'round_robin'::text,
  "territory_id" uuid,
  "max_leads_per_user" integer
);

CREATE TABLE IF NOT EXISTS "public"."lead_score_config" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "weights_json" jsonb NOT NULL DEFAULT '{}'::jsonb,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."lead_score_logs" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "lead_id" uuid NOT NULL,
  "old_score" integer,
  "new_score" integer,
  "change_reason" text,
  "created_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."lead_scoring_rules" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "criteria_type" text NOT NULL,
  "criteria_value" text NOT NULL,
  "score_points" integer NOT NULL,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."leads" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "franchise_id" uuid,
  "first_name" text NOT NULL,
  "last_name" text NOT NULL,
  "company" text,
  "title" text,
  "email" text,
  "phone" text,
  "status" USER-DEFINED DEFAULT 'new'::lead_status,
  "source" USER-DEFINED DEFAULT 'other'::lead_source,
  "estimated_value" numeric,
  "expected_close_date" date,
  "description" text,
  "notes" text,
  "owner_id" uuid,
  "converted_account_id" uuid,
  "converted_contact_id" uuid,
  "converted_at" timestamp with time zone,
  "created_by" uuid,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "lead_score" integer DEFAULT 0,
  "qualification_status" text DEFAULT 'unqualified'::text,
  "last_activity_date" timestamp with time zone,
  "conversion_probability" integer,
  "custom_fields" jsonb DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS "public"."margin_methods" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "name" text NOT NULL,
  "code" text NOT NULL,
  "is_active" boolean NOT NULL DEFAULT true,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."margin_profiles" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "default_method_id" uuid NOT NULL,
  "default_value" numeric NOT NULL,
  "rounding_rule" text,
  "min_margin" numeric,
  "is_active" boolean NOT NULL DEFAULT true,
  "created_at" timestamp with time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."oauth_configurations" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "user_id" uuid NOT NULL,
  "tenant_id" uuid,
  "provider" text NOT NULL,
  "client_id" text NOT NULL,
  "client_secret" text NOT NULL,
  "tenant_id_provider" text,
  "redirect_uri" text NOT NULL,
  "scopes" jsonb DEFAULT '[]'::jsonb,
  "is_active" boolean DEFAULT true,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now()
);

CREATE TABLE IF NOT EXISTS "public"."opportunities" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "franchise_id" uuid,
  "name" text NOT NULL,
  "description" text,
  "stage" USER-DEFINED NOT NULL DEFAULT 'prospecting'::opportunity_stage,
  "amount" numeric,
  "probability" integer,
  "close_date" date,
  "account_id" uuid,
  "contact_id" uuid,
  "lead_id" uuid,
  "owner_id" uuid,
  "lead_source" USER-DEFINED,
  "next_step" text,
  "competitors" text,
  "campaign_id" uuid,
  "type" text,
  "forecast_category" text,
  "expected_revenue" numeric,
  "created_by" uuid,
  "created_at" timestamp with time zone DEFAULT now(),
  "updated_at" timestamp with time zone DEFAULT now(),
  "closed_at" timestamp with time zone
);

CREATE TABLE IF NOT EXISTS "public"."package_categories" (
  "id" uuid NOT NULL DEFAULT gen_random_uuid(),
  "tenant_id" uuid NOT NULL,
  "category_name" text NOT NULL,
  "category_code" text
);

