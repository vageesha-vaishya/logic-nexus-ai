-- 007_rls_policies.sql
-- Row Level Security Policies


-- Enable RLS on public.accounts
ALTER TABLE "public"."accounts" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise accounts" ON "public"."accounts"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all accounts" ON "public"."accounts"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant accounts" ON "public"."accounts"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create franchise accounts" ON "public"."accounts"
  FOR INSERT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users can view franchise accounts" ON "public"."accounts"
  FOR SELECT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;

-- Enable RLS on public.activities
ALTER TABLE "public"."activities" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise activities" ON "public"."activities"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all activities" ON "public"."activities"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant activities" ON "public"."activities"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create activities" ON "public"."activities"
  FOR INSERT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users can update own activities" ON "public"."activities"
  FOR UPDATE
  TO PUBLIC
  USING ((assigned_to = auth.uid()))
;
CREATE POLICY "Users can view assigned activities" ON "public"."activities"
  FOR SELECT
  TO PUBLIC
  USING (((assigned_to = auth.uid()) OR (franchise_id = get_user_franchise_id(auth.uid()))))
;

-- Enable RLS on public.aes_hts_codes
ALTER TABLE "public"."aes_hts_codes" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can view HTS codes" ON "public"."aes_hts_codes"
  FOR SELECT
  TO "authenticated"
  USING (true)
;
CREATE POLICY "Platform admins can manage all HTS codes" ON "public"."aes_hts_codes"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;

-- Enable RLS on public.audit_logs
ALTER TABLE "public"."audit_logs" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can view all audit logs" ON "public"."audit_logs"
  FOR SELECT
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can view tenant audit logs" ON "public"."audit_logs"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (user_id IN ( SELECT ur.user_id
   FROM user_roles ur
  WHERE (ur.tenant_id = get_user_tenant_id(auth.uid()))))))
;

-- Enable RLS on public.auth_permissions
ALTER TABLE "public"."auth_permissions" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "All authenticated can read auth_permissions" ON "public"."auth_permissions"
  FOR SELECT
  TO PUBLIC
  USING ((auth.uid() IS NOT NULL))
;
CREATE POLICY "Platform admins can manage auth_permissions" ON "public"."auth_permissions"
  FOR ALL
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role)))))
;

-- Enable RLS on public.auth_role_permissions
ALTER TABLE "public"."auth_role_permissions" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "All authenticated can read auth_role_permissions" ON "public"."auth_role_permissions"
  FOR SELECT
  TO PUBLIC
  USING ((auth.uid() IS NOT NULL))
;
CREATE POLICY "Platform admins can manage auth_role_permissions" ON "public"."auth_role_permissions"
  FOR ALL
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role)))))
;

-- Enable RLS on public.auth_roles
ALTER TABLE "public"."auth_roles" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "All authenticated can read auth_roles" ON "public"."auth_roles"
  FOR SELECT
  TO PUBLIC
  USING ((auth.uid() IS NOT NULL))
;
CREATE POLICY "Platform admins can manage auth_roles" ON "public"."auth_roles"
  FOR ALL
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role)))))
;

-- Enable RLS on public.cargo_details
ALTER TABLE "public"."cargo_details" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all cargo details" ON "public"."cargo_details"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage cargo details" ON "public"."cargo_details"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create cargo details" ON "public"."cargo_details"
  FOR INSERT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "Users can view tenant cargo details" ON "public"."cargo_details"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.cargo_types
ALTER TABLE "public"."cargo_types" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all cargo types" ON "public"."cargo_types"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage cargo types" ON "public"."cargo_types"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant cargo types" ON "public"."cargo_types"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.carrier_rate_charges
ALTER TABLE "public"."carrier_rate_charges" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all carrier rate charges" ON "public"."carrier_rate_charges"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage carrier rate charges" ON "public"."carrier_rate_charges"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant carrier rate charges" ON "public"."carrier_rate_charges"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.carrier_rates
ALTER TABLE "public"."carrier_rates" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all rates" ON "public"."carrier_rates"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage rates" ON "public"."carrier_rates"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Tenant users can view rates" ON "public"."carrier_rates"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.carrier_service_types
ALTER TABLE "public"."carrier_service_types" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all carrier type mappings" ON "public"."carrier_service_types"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage own carrier type mappings" ON "public"."carrier_service_types"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view global carrier type mappings" ON "public"."carrier_service_types"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id IS NULL))
;
CREATE POLICY "Users can view tenant carrier type mappings" ON "public"."carrier_service_types"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.carriers
ALTER TABLE "public"."carriers" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all carriers" ON "public"."carriers"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage carriers" ON "public"."carriers"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view global carriers" ON "public"."carriers"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id IS NULL))
;
CREATE POLICY "Users can view tenant carriers" ON "public"."carriers"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.charge_bases
ALTER TABLE "public"."charge_bases" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all charge bases" ON "public"."charge_bases"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can view charge bases" ON "public"."charge_bases"
  FOR SELECT
  TO PUBLIC
  USING (true)
;

-- Enable RLS on public.charge_categories
ALTER TABLE "public"."charge_categories" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all charge categories" ON "public"."charge_categories"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can view charge categories" ON "public"."charge_categories"
  FOR SELECT
  TO PUBLIC
  USING (true)
;

-- Enable RLS on public.charge_sides
ALTER TABLE "public"."charge_sides" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all charge sides" ON "public"."charge_sides"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can view charge sides" ON "public"."charge_sides"
  FOR SELECT
  TO PUBLIC
  USING (true)
;

-- Enable RLS on public.charge_tier_config
ALTER TABLE "public"."charge_tier_config" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all tier configs" ON "public"."charge_tier_config"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tier configs" ON "public"."charge_tier_config"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant tier configs" ON "public"."charge_tier_config"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.charge_tier_ranges
ALTER TABLE "public"."charge_tier_ranges" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all tier ranges" ON "public"."charge_tier_ranges"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tier ranges" ON "public"."charge_tier_ranges"
  FOR ALL
  TO PUBLIC
  USING ((tier_config_id IN ( SELECT charge_tier_config.id
   FROM charge_tier_config
  WHERE (charge_tier_config.tenant_id = get_user_tenant_id(auth.uid())))))
;
CREATE POLICY "Users can view tenant tier ranges" ON "public"."charge_tier_ranges"
  FOR SELECT
  TO PUBLIC
  USING ((tier_config_id IN ( SELECT charge_tier_config.id
   FROM charge_tier_config
  WHERE (charge_tier_config.tenant_id = get_user_tenant_id(auth.uid())))))
;

-- Enable RLS on public.charge_weight_breaks
ALTER TABLE "public"."charge_weight_breaks" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all weight breaks" ON "public"."charge_weight_breaks"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage weight breaks" ON "public"."charge_weight_breaks"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant weight breaks" ON "public"."charge_weight_breaks"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.cities
ALTER TABLE "public"."cities" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "cities_manage" ON "public"."cities"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "cities_read" ON "public"."cities"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id IS NULL) OR (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.compliance_checks
ALTER TABLE "public"."compliance_checks" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can create compliance checks" ON "public"."compliance_checks"
  FOR INSERT
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE ((quotes.franchise_id = get_user_franchise_id(auth.uid())) OR (quotes.owner_id = auth.uid())))))
;
CREATE POLICY "Users can view compliance checks for accessible quotes" ON "public"."compliance_checks"
  FOR SELECT
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE ((quotes.franchise_id = get_user_franchise_id(auth.uid())) OR (quotes.owner_id = auth.uid())))))
;

-- Enable RLS on public.compliance_rules
ALTER TABLE "public"."compliance_rules" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all compliance rules" ON "public"."compliance_rules"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage compliance rules" ON "public"."compliance_rules"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Tenant users can view compliance rules" ON "public"."compliance_rules"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.consignees
ALTER TABLE "public"."consignees" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all consignees" ON "public"."consignees"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage consignees" ON "public"."consignees"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant consignees" ON "public"."consignees"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.contacts
ALTER TABLE "public"."contacts" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise contacts" ON "public"."contacts"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all contacts" ON "public"."contacts"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant contacts" ON "public"."contacts"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create franchise contacts" ON "public"."contacts"
  FOR INSERT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users can view franchise contacts" ON "public"."contacts"
  FOR SELECT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;

-- Enable RLS on public.container_sizes
ALTER TABLE "public"."container_sizes" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all container sizes" ON "public"."container_sizes"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage container sizes" ON "public"."container_sizes"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Tenant users can view container sizes" ON "public"."container_sizes"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id = get_user_tenant_id(auth.uid())) OR (tenant_id IS NULL)))
;

-- Enable RLS on public.container_types
ALTER TABLE "public"."container_types" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all container types" ON "public"."container_types"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage container types" ON "public"."container_types"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Tenant users can view container types" ON "public"."container_types"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id = get_user_tenant_id(auth.uid())) OR (tenant_id IS NULL)))
;

-- Enable RLS on public.continents
ALTER TABLE "public"."continents" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "continents_manage" ON "public"."continents"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "continents_read" ON "public"."continents"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id IS NULL) OR (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.countries
ALTER TABLE "public"."countries" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "countries_manage" ON "public"."countries"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "countries_read" ON "public"."countries"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id IS NULL) OR (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.currencies
ALTER TABLE "public"."currencies" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all currencies" ON "public"."currencies"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can view currencies" ON "public"."currencies"
  FOR SELECT
  TO PUBLIC
  USING (true)
;

-- Enable RLS on public.custom_role_permissions
ALTER TABLE "public"."custom_role_permissions" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all custom role permissions" ON "public"."custom_role_permissions"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant custom role permissions" ON "public"."custom_role_permissions"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (role_id IN ( SELECT custom_roles.id
   FROM custom_roles
  WHERE (custom_roles.tenant_id = get_user_tenant_id(auth.uid()))))))
;
CREATE POLICY "Users can view custom role permissions" ON "public"."custom_role_permissions"
  FOR SELECT
  TO PUBLIC
  USING ((role_id IN ( SELECT custom_roles.id
   FROM custom_roles
  WHERE (custom_roles.tenant_id = get_user_tenant_id(auth.uid())))))
;

-- Enable RLS on public.custom_roles
ALTER TABLE "public"."custom_roles" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all custom roles" ON "public"."custom_roles"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant custom roles" ON "public"."custom_roles"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant custom roles" ON "public"."custom_roles"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.customer_selections
ALTER TABLE "public"."customer_selections" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins full access to customer selections" ON "public"."customer_selections"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can create customer selections" ON "public"."customer_selections"
  FOR INSERT
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "Users can view franchise customer selections" ON "public"."customer_selections"
  FOR SELECT
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.customs_documents
ALTER TABLE "public"."customs_documents" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all customs documents" ON "public"."customs_documents"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can manage customs documents for accessible shipments" ON "public"."customs_documents"
  FOR ALL
  TO PUBLIC
  USING ((shipment_id IN ( SELECT shipments.id
   FROM shipments
  WHERE ((shipments.franchise_id = get_user_franchise_id(auth.uid())) OR (shipments.assigned_to = auth.uid())))))
;

-- Enable RLS on public.dashboard_preferences
ALTER TABLE "public"."dashboard_preferences" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can delete own dashboard preferences" ON "public"."dashboard_preferences"
  FOR DELETE
  TO "authenticated"
  USING ((user_id = auth.uid()))
;
CREATE POLICY "Users can insert own dashboard preferences" ON "public"."dashboard_preferences"
  FOR INSERT
  TO "authenticated"
  USING ((user_id = auth.uid()))
;
CREATE POLICY "Users can update own dashboard preferences" ON "public"."dashboard_preferences"
  FOR UPDATE
  TO "authenticated"
  USING ((user_id = auth.uid()))
;
CREATE POLICY "Users can view own dashboard preferences" ON "public"."dashboard_preferences"
  FOR SELECT
  TO "authenticated"
  USING ((user_id = auth.uid()))
;

-- Enable RLS on public.document_templates
ALTER TABLE "public"."document_templates" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all templates" ON "public"."document_templates"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage templates" ON "public"."document_templates"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Tenant users can view templates" ON "public"."document_templates"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.email_account_delegations
ALTER TABLE "public"."email_account_delegations" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Delegates can view their delegations" ON "public"."email_account_delegations"
  FOR SELECT
  TO PUBLIC
  USING ((delegate_user_id = auth.uid()))
;
CREATE POLICY "Delegation owners can manage" ON "public"."email_account_delegations"
  FOR ALL
  TO PUBLIC
  USING ((account_id IN ( SELECT email_accounts.id
   FROM email_accounts
  WHERE (email_accounts.user_id = auth.uid()))))
;
CREATE POLICY "Franchise admins can view franchise delegations" ON "public"."email_account_delegations"
  FOR SELECT
  TO PUBLIC
  USING ((is_franchise_admin(auth.uid()) AND (account_id IN ( SELECT email_accounts.id
   FROM email_accounts
  WHERE ((email_accounts.franchise_id = get_user_franchise_id(auth.uid())) AND (email_accounts.tenant_id = get_user_tenant_id(auth.uid())))))))
;
CREATE POLICY "Platform admins can manage all delegations" ON "public"."email_account_delegations"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can view delegations" ON "public"."email_account_delegations"
  FOR SELECT
  TO PUBLIC
  USING ((is_tenant_admin(auth.uid()) AND (account_id IN ( SELECT email_accounts.id
   FROM email_accounts
  WHERE (email_accounts.tenant_id = get_user_tenant_id(auth.uid()))))))
;

-- Enable RLS on public.email_accounts
ALTER TABLE "public"."email_accounts" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Email accounts scope matrix - DELETE" ON "public"."email_accounts"
  FOR DELETE
  TO "authenticated"
  USING (((user_id = auth.uid()) OR is_platform_admin(auth.uid())))
;
CREATE POLICY "Email accounts scope matrix - INSERT" ON "public"."email_accounts"
  FOR INSERT
  TO "authenticated"
  USING (((user_id = auth.uid()) OR is_platform_admin(auth.uid())))
;
CREATE POLICY "Email accounts scope matrix - SELECT" ON "public"."email_accounts"
  FOR SELECT
  TO "authenticated"
  USING (((user_id = auth.uid()) OR is_platform_admin(auth.uid()) OR (is_tenant_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid()))) OR (is_franchise_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid())) AND (franchise_id = get_user_franchise_id(auth.uid()))) OR (id IN ( SELECT get_delegated_email_account_ids(auth.uid()) AS get_delegated_email_account_ids))))
;
CREATE POLICY "Email accounts scope matrix - UPDATE" ON "public"."email_accounts"
  FOR UPDATE
  TO "authenticated"
  USING (((user_id = auth.uid()) OR is_platform_admin(auth.uid())))
;

-- Enable RLS on public.email_audit_log
ALTER TABLE "public"."email_audit_log" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Authenticated users can insert audit logs for their actions" ON "public"."email_audit_log"
  FOR INSERT
  TO "authenticated"
  USING (((user_id = auth.uid()) OR is_super_admin(auth.uid()) OR (is_tenant_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid()))) OR (is_franchise_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid())) AND (franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "Franchise admins can view franchise audit logs" ON "public"."email_audit_log"
  FOR SELECT
  TO "authenticated"
  USING ((is_franchise_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid())) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Super admins can view all audit logs" ON "public"."email_audit_log"
  FOR SELECT
  TO "authenticated"
  USING (is_super_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can view tenant audit logs" ON "public"."email_audit_log"
  FOR SELECT
  TO "authenticated"
  USING ((is_tenant_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view own audit logs" ON "public"."email_audit_log"
  FOR SELECT
  TO "authenticated"
  USING ((user_id = auth.uid()))
;

-- Enable RLS on public.email_filters
ALTER TABLE "public"."email_filters" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all email filters" ON "public"."email_filters"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can manage own email filters" ON "public"."email_filters"
  FOR ALL
  TO PUBLIC
  USING ((user_id = auth.uid()))
;

-- Enable RLS on public.email_templates
ALTER TABLE "public"."email_templates" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all templates" ON "public"."email_templates"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can create templates" ON "public"."email_templates"
  FOR INSERT
  TO PUBLIC
  USING (((tenant_id = get_user_tenant_id(auth.uid())) AND (created_by = auth.uid())))
;
CREATE POLICY "Users can delete own templates" ON "public"."email_templates"
  FOR DELETE
  TO PUBLIC
  USING ((created_by = auth.uid()))
;
CREATE POLICY "Users can update own templates" ON "public"."email_templates"
  FOR UPDATE
  TO PUBLIC
  USING ((created_by = auth.uid()))
;
CREATE POLICY "Users can view tenant templates" ON "public"."email_templates"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id = get_user_tenant_id(auth.uid())) AND ((is_shared = true) OR (created_by = auth.uid()))))
;

-- Enable RLS on public.emails
ALTER TABLE "public"."emails" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Email scope matrix - DELETE" ON "public"."emails"
  FOR DELETE
  TO "authenticated"
  USING (((NOT is_viewer(auth.uid())) AND ((user_id = auth.uid()) OR (account_id IN ( SELECT get_user_email_account_ids(auth.uid()) AS get_user_email_account_ids)) OR is_platform_admin(auth.uid()) OR (is_tenant_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid()))))))
;
CREATE POLICY "Email scope matrix - INSERT" ON "public"."emails"
  FOR INSERT
  TO "authenticated"
  USING (((user_id = auth.uid()) OR (account_id IN ( SELECT get_user_email_account_ids(auth.uid()) AS get_user_email_account_ids)) OR is_platform_admin(auth.uid())))
;
CREATE POLICY "Email scope matrix - SELECT" ON "public"."emails"
  FOR SELECT
  TO "authenticated"
  USING ((is_platform_admin(auth.uid()) OR is_super_admin(auth.uid()) OR (is_tenant_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid()))) OR (is_franchise_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid())) AND (franchise_id = get_user_franchise_id(auth.uid()))) OR (user_id = auth.uid()) OR (account_id IN ( SELECT get_user_email_account_ids(auth.uid()) AS get_user_email_account_ids)) OR (account_id IN ( SELECT get_delegated_email_account_ids(auth.uid()) AS get_delegated_email_account_ids))))
;
CREATE POLICY "Email scope matrix - UPDATE" ON "public"."emails"
  FOR UPDATE
  TO "authenticated"
  USING (((NOT is_viewer(auth.uid())) AND ((user_id = auth.uid()) OR (account_id IN ( SELECT get_user_email_account_ids(auth.uid()) AS get_user_email_account_ids)) OR is_platform_admin(auth.uid()) OR (is_tenant_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid()))) OR (is_franchise_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid())) AND (franchise_id = get_user_franchise_id(auth.uid()))))))
;
CREATE POLICY "Users can view emails in their queues" ON "public"."emails"
  FOR SELECT
  TO "authenticated"
  USING (((queue IS NOT NULL) AND (EXISTS ( SELECT 1
   FROM (queues q
     JOIN queue_members qm ON ((q.id = qm.queue_id)))
  WHERE ((q.name = emails.queue) AND (q.tenant_id = emails.tenant_id) AND (qm.user_id = auth.uid()))))))
;

-- Enable RLS on public.entity_transfer_items
ALTER TABLE "public"."entity_transfer_items" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Entity transfer items: delete (platform admin)" ON "public"."entity_transfer_items"
  FOR DELETE
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Entity transfer items: insert" ON "public"."entity_transfer_items"
  FOR INSERT
  TO PUBLIC
  USING ((is_platform_admin(auth.uid()) OR (EXISTS ( SELECT 1
   FROM entity_transfers et
  WHERE ((et.id = entity_transfer_items.transfer_id) AND (et.source_tenant_id IN ( SELECT ur.tenant_id
           FROM user_roles ur
          WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL)))))))))
;
CREATE POLICY "Entity transfer items: select" ON "public"."entity_transfer_items"
  FOR SELECT
  TO PUBLIC
  USING ((is_platform_admin(auth.uid()) OR (EXISTS ( SELECT 1
   FROM entity_transfers et
  WHERE ((et.id = entity_transfer_items.transfer_id) AND ((et.source_tenant_id IN ( SELECT ur.tenant_id
           FROM user_roles ur
          WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL)))) OR (et.target_tenant_id IN ( SELECT ur.tenant_id
           FROM user_roles ur
          WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))))))))
;
CREATE POLICY "Entity transfer items: update (platform admin)" ON "public"."entity_transfer_items"
  FOR UPDATE
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;

-- Enable RLS on public.entity_transfers
ALTER TABLE "public"."entity_transfers" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Entity transfers: delete (platform admin)" ON "public"."entity_transfers"
  FOR DELETE
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Entity transfers: insert" ON "public"."entity_transfers"
  FOR INSERT
  TO PUBLIC
  USING (((is_platform_admin(auth.uid()) OR (source_tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))) AND (requested_by = auth.uid())))
;
CREATE POLICY "Entity transfers: select" ON "public"."entity_transfers"
  FOR SELECT
  TO PUBLIC
  USING ((is_platform_admin(auth.uid()) OR (source_tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL)))) OR (target_tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))))
;
CREATE POLICY "Entity transfers: update" ON "public"."entity_transfers"
  FOR UPDATE
  TO PUBLIC
  USING ((is_platform_admin(auth.uid()) OR (target_tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))))
;

-- Enable RLS on public.franchises
ALTER TABLE "public"."franchises" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can update own franchise" ON "public"."franchises"
  FOR UPDATE
  TO PUBLIC
  USING ((id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Franchise admins can view own franchise" ON "public"."franchises"
  FOR SELECT
  TO PUBLIC
  USING ((id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Platform admins full access to franchises" ON "public"."franchises"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant franchises" ON "public"."franchises"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "Users can view own franchise" ON "public"."franchises"
  FOR SELECT
  TO PUBLIC
  USING ((id = get_user_franchise_id(auth.uid())))
;

-- Enable RLS on public.fx_rates
ALTER TABLE "public"."fx_rates" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "fx_rates_tenant_read" ON "public"."fx_rates"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "fx_rates_tenant_write" ON "public"."fx_rates"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.import_errors
ALTER TABLE "public"."import_errors" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Import errors: delete (platform admin)" ON "public"."import_errors"
  FOR DELETE
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Import errors: insert" ON "public"."import_errors"
  FOR INSERT
  TO PUBLIC
  USING ((is_platform_admin(auth.uid()) OR (EXISTS ( SELECT 1
   FROM import_history ih
  WHERE ((ih.id = import_errors.import_id) AND (ih.tenant_id IN ( SELECT ur.tenant_id
           FROM user_roles ur
          WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL)))))))))
;
CREATE POLICY "Import errors: select" ON "public"."import_errors"
  FOR SELECT
  TO PUBLIC
  USING ((is_platform_admin(auth.uid()) OR (EXISTS ( SELECT 1
   FROM import_history ih
  WHERE ((ih.id = import_errors.import_id) AND (ih.tenant_id IN ( SELECT ur.tenant_id
           FROM user_roles ur
          WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL)))))))))
;
CREATE POLICY "Import errors: update (platform admin)" ON "public"."import_errors"
  FOR UPDATE
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;

-- Enable RLS on public.import_history
ALTER TABLE "public"."import_history" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Import history: insert" ON "public"."import_history"
  FOR INSERT
  TO PUBLIC
  USING (((EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'platform_admin'::app_role)))) OR (tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))))
;
CREATE POLICY "Import history: select" ON "public"."import_history"
  FOR SELECT
  TO PUBLIC
  USING (((EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'platform_admin'::app_role)))) OR (tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))))
;
CREATE POLICY "Import history: update" ON "public"."import_history"
  FOR UPDATE
  TO PUBLIC
  USING (((EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'platform_admin'::app_role)))) OR (tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))))
;

-- Enable RLS on public.import_history_details
ALTER TABLE "public"."import_history_details" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Import details: insert" ON "public"."import_history_details"
  FOR INSERT
  TO PUBLIC
  USING (((EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'platform_admin'::app_role)))) OR (import_id IN ( SELECT ih.id
   FROM import_history ih
  WHERE (ih.tenant_id IN ( SELECT ur.tenant_id
           FROM user_roles ur
          WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))))))
;
CREATE POLICY "Import details: select" ON "public"."import_history_details"
  FOR SELECT
  TO PUBLIC
  USING (((EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'platform_admin'::app_role)))) OR (import_id IN ( SELECT ih.id
   FROM import_history ih
  WHERE (ih.tenant_id IN ( SELECT ur.tenant_id
           FROM user_roles ur
          WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))))))
;
CREATE POLICY "Import details: update" ON "public"."import_history_details"
  FOR UPDATE
  TO PUBLIC
  USING (((EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'platform_admin'::app_role)))) OR (import_id IN ( SELECT ih.id
   FROM import_history ih
  WHERE (ih.tenant_id IN ( SELECT ur.tenant_id
           FROM user_roles ur
          WHERE ((ur.user_id = auth.uid()) AND (ur.tenant_id IS NOT NULL))))))))
;

-- Enable RLS on public.incoterms
ALTER TABLE "public"."incoterms" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all incoterms" ON "public"."incoterms"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage incoterms" ON "public"."incoterms"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant incoterms" ON "public"."incoterms"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.invitations
ALTER TABLE "public"."invitations" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise invitations" ON "public"."invitations"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins full access to invitations" ON "public"."invitations"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant invitations" ON "public"."invitations"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.lead_activities
ALTER TABLE "public"."lead_activities" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage their tenant lead activities" ON "public"."lead_activities"
  FOR ALL
  TO PUBLIC
  USING (((lead_id IN ( SELECT leads.id
   FROM leads
  WHERE (leads.tenant_id IN ( SELECT user_roles.tenant_id
           FROM user_roles
          WHERE (user_roles.user_id = auth.uid()))))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;
CREATE POLICY "Users can view their tenant lead activities" ON "public"."lead_activities"
  FOR SELECT
  TO PUBLIC
  USING (((lead_id IN ( SELECT leads.id
   FROM leads
  WHERE (leads.tenant_id IN ( SELECT user_roles.tenant_id
           FROM user_roles
          WHERE (user_roles.user_id = auth.uid()))))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;

-- Enable RLS on public.lead_assignment_history
ALTER TABLE "public"."lead_assignment_history" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can view franchise assignment history" ON "public"."lead_assignment_history"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all assignment history" ON "public"."lead_assignment_history"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can view tenant assignment history" ON "public"."lead_assignment_history"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.lead_assignment_queue
ALTER TABLE "public"."lead_assignment_queue" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all assignment queue" ON "public"."lead_assignment_queue"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can view tenant assignment queue" ON "public"."lead_assignment_queue"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.lead_assignment_rules
ALTER TABLE "public"."lead_assignment_rules" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all assignment rules" ON "public"."lead_assignment_rules"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant assignment rules" ON "public"."lead_assignment_rules"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.lead_score_config
ALTER TABLE "public"."lead_score_config" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins can manage score config" ON "public"."lead_score_config"
  FOR ALL
  TO PUBLIC
  USING (((tenant_id IN ( SELECT user_roles.tenant_id
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = ANY (ARRAY['tenant_admin'::app_role, 'platform_admin'::app_role]))))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;
CREATE POLICY "Users can view their tenant score config" ON "public"."lead_score_config"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id IN ( SELECT user_roles.tenant_id
   FROM user_roles
  WHERE (user_roles.user_id = auth.uid()))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;

-- Enable RLS on public.lead_score_logs
ALTER TABLE "public"."lead_score_logs" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view their tenant score logs" ON "public"."lead_score_logs"
  FOR SELECT
  TO PUBLIC
  USING (((lead_id IN ( SELECT leads.id
   FROM leads
  WHERE (leads.tenant_id IN ( SELECT user_roles.tenant_id
           FROM user_roles
          WHERE (user_roles.user_id = auth.uid()))))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;

-- Enable RLS on public.lead_scoring_rules
ALTER TABLE "public"."lead_scoring_rules" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all scoring rules" ON "public"."lead_scoring_rules"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant scoring rules" ON "public"."lead_scoring_rules"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.leads
ALTER TABLE "public"."leads" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise leads" ON "public"."leads"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all leads" ON "public"."leads"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant leads" ON "public"."leads"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create franchise leads" ON "public"."leads"
  FOR INSERT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users can view franchise leads" ON "public"."leads"
  FOR SELECT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;

-- Enable RLS on public.margin_methods
ALTER TABLE "public"."margin_methods" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "margin_methods_tenant_read" ON "public"."margin_methods"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "margin_methods_tenant_write" ON "public"."margin_methods"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.margin_profiles
ALTER TABLE "public"."margin_profiles" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "margin_profiles_tenant_read" ON "public"."margin_profiles"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "margin_profiles_tenant_write" ON "public"."margin_profiles"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.oauth_configurations
ALTER TABLE "public"."oauth_configurations" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all OAuth configs" ON "public"."oauth_configurations"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can manage own OAuth configs" ON "public"."oauth_configurations"
  FOR ALL
  TO PUBLIC
  USING ((user_id = auth.uid()))
;

-- Enable RLS on public.opportunities
ALTER TABLE "public"."opportunities" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise opportunities" ON "public"."opportunities"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all opportunities" ON "public"."opportunities"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant opportunities" ON "public"."opportunities"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create franchise opportunities" ON "public"."opportunities"
  FOR INSERT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users can update assigned opportunities" ON "public"."opportunities"
  FOR UPDATE
  TO PUBLIC
  USING ((owner_id = auth.uid()))
;
CREATE POLICY "Users can view franchise opportunities" ON "public"."opportunities"
  FOR SELECT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;

-- Enable RLS on public.package_categories
ALTER TABLE "public"."package_categories" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all package categories" ON "public"."package_categories"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage package categories" ON "public"."package_categories"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant package categories" ON "public"."package_categories"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.package_sizes
ALTER TABLE "public"."package_sizes" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all package sizes" ON "public"."package_sizes"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage package sizes" ON "public"."package_sizes"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant package sizes" ON "public"."package_sizes"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.portal_tokens
ALTER TABLE "public"."portal_tokens" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage their quote tokens" ON "public"."portal_tokens"
  FOR ALL
  TO PUBLIC
  USING (((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.tenant_id IN ( SELECT user_roles.tenant_id
           FROM user_roles
          WHERE (user_roles.user_id = auth.uid()))))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;
CREATE POLICY "Users can view their quote tokens" ON "public"."portal_tokens"
  FOR SELECT
  TO PUBLIC
  USING (((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.tenant_id IN ( SELECT user_roles.tenant_id
           FROM user_roles
          WHERE (user_roles.user_id = auth.uid()))))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;

-- Enable RLS on public.ports_locations
ALTER TABLE "public"."ports_locations" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all ports" ON "public"."ports_locations"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage ports" ON "public"."ports_locations"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view global ports" ON "public"."ports_locations"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id IS NULL))
;
CREATE POLICY "Users can view tenant ports" ON "public"."ports_locations"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.profiles
ALTER TABLE "public"."profiles" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can view franchise profiles" ON "public"."profiles"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (id IN ( SELECT user_roles.user_id
   FROM user_roles
  WHERE (user_roles.franchise_id = get_user_franchise_id(auth.uid()))))))
;
CREATE POLICY "Platform admins can insert profiles" ON "public"."profiles"
  FOR INSERT
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Platform admins can update all profiles" ON "public"."profiles"
  FOR UPDATE
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Platform admins can view all profiles" ON "public"."profiles"
  FOR SELECT
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can view tenant profiles" ON "public"."profiles"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (id IN ( SELECT user_roles.user_id
   FROM user_roles
  WHERE (user_roles.tenant_id = get_user_tenant_id(auth.uid()))))))
;
CREATE POLICY "Users can update own profile" ON "public"."profiles"
  FOR UPDATE
  TO PUBLIC
  USING ((auth.uid() = id))
;
CREATE POLICY "Users can view own profile" ON "public"."profiles"
  FOR SELECT
  TO PUBLIC
  USING ((auth.uid() = id))
;

-- Enable RLS on public.provider_api_configs
ALTER TABLE "public"."provider_api_configs" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins full access to provider api configs" ON "public"."provider_api_configs"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins manage provider api configs" ON "public"."provider_api_configs"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.provider_charge_mappings
ALTER TABLE "public"."provider_charge_mappings" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins full access to provider charge mappings" ON "public"."provider_charge_mappings"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins manage provider charge mappings" ON "public"."provider_charge_mappings"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users view tenant provider charge mappings" ON "public"."provider_charge_mappings"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.provider_rate_rules
ALTER TABLE "public"."provider_rate_rules" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins full access to provider rate rules" ON "public"."provider_rate_rules"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins manage provider rate rules" ON "public"."provider_rate_rules"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users view tenant provider rate rules" ON "public"."provider_rate_rules"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.provider_rate_templates
ALTER TABLE "public"."provider_rate_templates" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins full access to provider rate templates" ON "public"."provider_rate_templates"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins manage provider rate templates" ON "public"."provider_rate_templates"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users view tenant provider rate templates" ON "public"."provider_rate_templates"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.provider_surcharges
ALTER TABLE "public"."provider_surcharges" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins full access to provider surcharges" ON "public"."provider_surcharges"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins manage provider surcharges" ON "public"."provider_surcharges"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users view tenant provider surcharges" ON "public"."provider_surcharges"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.provider_types
ALTER TABLE "public"."provider_types" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "provider_types_tenant_read" ON "public"."provider_types"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "provider_types_tenant_write" ON "public"."provider_types"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.queue_members
ALTER TABLE "public"."queue_members" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all queue members" ON "public"."queue_members"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage members of their tenant queues" ON "public"."queue_members"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (EXISTS ( SELECT 1
   FROM queues q
  WHERE ((q.id = queue_members.queue_id) AND (q.tenant_id = get_user_tenant_id(auth.uid())))))))
;
CREATE POLICY "Tenant admins can manage queue memberships" ON "public"."queue_members"
  FOR ALL
  TO "authenticated"
  USING ((EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'tenant_admin'::app_role)))))
;
CREATE POLICY "Users can view their queue memberships" ON "public"."queue_members"
  FOR SELECT
  TO "authenticated"
  USING (((user_id = auth.uid()) OR (EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'tenant_admin'::app_role))))))
;

-- Enable RLS on public.queue_rules
ALTER TABLE "public"."queue_rules" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Tenant admins can manage queue rules" ON "public"."queue_rules"
  FOR ALL
  TO "authenticated"
  USING (((tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE (ur.user_id = auth.uid()))) AND (EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'tenant_admin'::app_role))))))
;

-- Enable RLS on public.queues
ALTER TABLE "public"."queues" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all queues" ON "public"."queues"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage queues" ON "public"."queues"
  FOR ALL
  TO "authenticated"
  USING (((tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE (ur.user_id = auth.uid()))) AND (EXISTS ( SELECT 1
   FROM user_roles ur
  WHERE ((ur.user_id = auth.uid()) AND (ur.role = 'tenant_admin'::app_role))))))
;
CREATE POLICY "Tenant admins can manage tenant queues" ON "public"."queues"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view queues in their tenant" ON "public"."queues"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id IN ( SELECT ur.tenant_id
   FROM user_roles ur
  WHERE (ur.user_id = auth.uid()))))
;

-- Enable RLS on public.quotation_audit_log
ALTER TABLE "public"."quotation_audit_log" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can view all audit logs" ON "public"."quotation_audit_log"
  FOR SELECT
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can view all audit logs" ON "public"."quotation_audit_log"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view franchise audit logs" ON "public"."quotation_audit_log"
  FOR SELECT
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.quotation_packages
ALTER TABLE "public"."quotation_packages" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all quotation packages" ON "public"."quotation_packages"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant quotation packages" ON "public"."quotation_packages"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create quotation packages" ON "public"."quotation_packages"
  FOR INSERT
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "Users can update quotation packages" ON "public"."quotation_packages"
  FOR UPDATE
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "Users can view franchise quotation packages" ON "public"."quotation_packages"
  FOR SELECT
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.quotation_version_option_legs
ALTER TABLE "public"."quotation_version_option_legs" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins manage franchise option legs" ON "public"."quotation_version_option_legs"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND ((franchise_id = get_user_franchise_id(auth.uid())) OR (franchise_id IS NULL))))
;
CREATE POLICY "Platform admins full access to option legs" ON "public"."quotation_version_option_legs"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins manage tenant option legs" ON "public"."quotation_version_option_legs"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users create franchise option legs" ON "public"."quotation_version_option_legs"
  FOR INSERT
  TO "authenticated"
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users view franchise option legs" ON "public"."quotation_version_option_legs"
  FOR SELECT
  TO "authenticated"
  USING (((franchise_id = get_user_franchise_id(auth.uid())) OR (franchise_id IS NULL)))
;
CREATE POLICY "quotation_version_option_legs_manage_alignment" ON "public"."quotation_version_option_legs"
  FOR ALL
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM ((quotation_version_options qvo
     JOIN quotation_versions qv ON ((qv.id = qvo.quotation_version_id)))
     JOIN quotes q ON ((q.id = qv.quote_id)))
  WHERE ((qvo.id = quotation_version_option_legs.quotation_version_option_id) AND ((q.tenant_id = get_user_tenant_id(auth.uid())) OR (q.franchise_id = get_user_franchise_id(auth.uid())) OR is_platform_admin(auth.uid()))))))
;
CREATE POLICY "quotation_version_option_legs_read" ON "public"."quotation_version_option_legs"
  FOR SELECT
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM quotation_version_options qvo
  WHERE ((qvo.id = quotation_version_option_legs.quotation_version_option_id) AND (qvo.tenant_id = get_user_tenant_id(auth.uid()))))))
;
CREATE POLICY "quotation_version_option_legs_read_alignment" ON "public"."quotation_version_option_legs"
  FOR SELECT
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM ((quotation_version_options qvo
     JOIN quotation_versions qv ON ((qv.id = qvo.quotation_version_id)))
     JOIN quotes q ON ((q.id = qv.quote_id)))
  WHERE ((qvo.id = quotation_version_option_legs.quotation_version_option_id) AND ((q.tenant_id = get_user_tenant_id(auth.uid())) OR (q.franchise_id = get_user_franchise_id(auth.uid())) OR is_platform_admin(auth.uid()))))))
;
CREATE POLICY "quotation_version_option_legs_write" ON "public"."quotation_version_option_legs"
  FOR ALL
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM quotation_version_options qvo
  WHERE ((qvo.id = quotation_version_option_legs.quotation_version_option_id) AND (qvo.tenant_id = get_user_tenant_id(auth.uid()))))))
;

-- Enable RLS on public.quotation_version_options
ALTER TABLE "public"."quotation_version_options" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins manage franchise quotation options" ON "public"."quotation_version_options"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND ((franchise_id = get_user_franchise_id(auth.uid())) OR (franchise_id IS NULL))))
;
CREATE POLICY "Platform admins can manage all quotation version options" ON "public"."quotation_version_options"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Platform admins full access to quotation options" ON "public"."quotation_version_options"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Platform admins full access to version options" ON "public"."quotation_version_options"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins manage tenant quotation options" ON "public"."quotation_version_options"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create version options" ON "public"."quotation_version_options"
  FOR INSERT
  TO PUBLIC
  USING ((quotation_version_id IN ( SELECT qv.id
   FROM (quotation_versions qv
     JOIN quotes q ON ((qv.quote_id = q.id)))
  WHERE (q.franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "Users can manage options for accessible versions" ON "public"."quotation_version_options"
  FOR ALL
  TO PUBLIC
  USING ((quotation_version_id IN ( SELECT qv.id
   FROM (quotation_versions qv
     JOIN quotes q ON ((qv.quote_id = q.id)))
  WHERE ((q.franchise_id = get_user_franchise_id(auth.uid())) OR (q.owner_id = auth.uid())))))
;
CREATE POLICY "Users can view franchise version options" ON "public"."quotation_version_options"
  FOR SELECT
  TO PUBLIC
  USING ((quotation_version_id IN ( SELECT qv.id
   FROM (quotation_versions qv
     JOIN quotes q ON ((qv.quote_id = q.id)))
  WHERE (q.franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "Users create franchise quotation options" ON "public"."quotation_version_options"
  FOR INSERT
  TO "authenticated"
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users view franchise quotation options" ON "public"."quotation_version_options"
  FOR SELECT
  TO "authenticated"
  USING (((franchise_id = get_user_franchise_id(auth.uid())) OR (franchise_id IS NULL)))
;

-- Enable RLS on public.quotation_versions
ALTER TABLE "public"."quotation_versions" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins manage franchise quotation versions" ON "public"."quotation_versions"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND ((franchise_id = get_user_franchise_id(auth.uid())) OR (franchise_id IS NULL))))
;
CREATE POLICY "Platform admins full access to quotation versions" ON "public"."quotation_versions"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Platform admins full access to quote versions" ON "public"."quotation_versions"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins manage tenant quotation versions" ON "public"."quotation_versions"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create quote versions" ON "public"."quotation_versions"
  FOR INSERT
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "Users can manage versions for accessible quotes" ON "public"."quotation_versions"
  FOR ALL
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE ((quotes.franchise_id = get_user_franchise_id(auth.uid())) OR (quotes.owner_id = auth.uid())))))
;
CREATE POLICY "Users can view franchise quote versions" ON "public"."quotation_versions"
  FOR SELECT
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "Users create franchise quotation versions" ON "public"."quotation_versions"
  FOR INSERT
  TO "authenticated"
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users view franchise quotation versions" ON "public"."quotation_versions"
  FOR SELECT
  TO "authenticated"
  USING (((franchise_id = get_user_franchise_id(auth.uid())) OR (franchise_id IS NULL)))
;
CREATE POLICY "quotation_versions_manage" ON "public"."quotation_versions"
  FOR ALL
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM quotes q
  WHERE ((q.id = quotation_versions.quote_id) AND (q.tenant_id = get_user_tenant_id(auth.uid()))))))
;
CREATE POLICY "quotation_versions_read" ON "public"."quotation_versions"
  FOR SELECT
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM quotes q
  WHERE ((q.id = quotation_versions.quote_id) AND (q.tenant_id = get_user_tenant_id(auth.uid()))))))
;

-- Enable RLS on public.quote_access_logs
ALTER TABLE "public"."quote_access_logs" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "qal_insert" ON "public"."quote_access_logs"
  FOR INSERT
  TO "anon", "authenticated"
  USING (true)
;
CREATE POLICY "qal_view" ON "public"."quote_access_logs"
  FOR SELECT
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.quote_charges
ALTER TABLE "public"."quote_charges" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins manage franchise quote charges" ON "public"."quote_charges"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND ((franchise_id = get_user_franchise_id(auth.uid())) OR (franchise_id IS NULL))))
;
CREATE POLICY "Platform admins full access to quote charges" ON "public"."quote_charges"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins manage tenant quote charges" ON "public"."quote_charges"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users create franchise quote charges" ON "public"."quote_charges"
  FOR INSERT
  TO "authenticated"
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users view franchise quote charges" ON "public"."quote_charges"
  FOR SELECT
  TO "authenticated"
  USING (((franchise_id = get_user_franchise_id(auth.uid())) OR (franchise_id IS NULL)))
;

-- Enable RLS on public.quote_comments
ALTER TABLE "public"."quote_comments" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "qc_admin" ON "public"."quote_comments"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "qc_public" ON "public"."quote_comments"
  FOR INSERT
  TO "anon", "authenticated"
  USING ((author_type = 'customer'::text))
;
CREATE POLICY "qc_user" ON "public"."quote_comments"
  FOR ALL
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.quote_documents
ALTER TABLE "public"."quote_documents" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "qd_admin" ON "public"."quote_documents"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "qd_public" ON "public"."quote_documents"
  FOR SELECT
  TO "anon", "authenticated"
  USING ((is_public = true))
;
CREATE POLICY "qd_user" ON "public"."quote_documents"
  FOR ALL
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.quote_email_history
ALTER TABLE "public"."quote_email_history" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "qeh_insert" ON "public"."quote_email_history"
  FOR INSERT
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "qeh_view" ON "public"."quote_email_history"
  FOR SELECT
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.quote_items
ALTER TABLE "public"."quote_items" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all quote items" ON "public"."quote_items"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can manage items for accessible quotes" ON "public"."quote_items"
  FOR ALL
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE ((quotes.franchise_id = get_user_franchise_id(auth.uid())) OR (quotes.owner_id = auth.uid())))))
;

-- Enable RLS on public.quote_legs
ALTER TABLE "public"."quote_legs" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all quote legs" ON "public"."quote_legs"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant quote legs" ON "public"."quote_legs"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create franchise quote legs" ON "public"."quote_legs"
  FOR INSERT
  TO PUBLIC
  USING ((quote_option_id IN ( SELECT qvo.id
   FROM ((quotation_version_options qvo
     JOIN quotation_versions qv ON ((qvo.quotation_version_id = qv.id)))
     JOIN quotes q ON ((qv.quote_id = q.id)))
  WHERE (q.franchise_id = get_user_franchise_id(auth.uid())))))
;
CREATE POLICY "Users can view franchise quote legs" ON "public"."quote_legs"
  FOR SELECT
  TO PUBLIC
  USING ((quote_option_id IN ( SELECT qvo.id
   FROM ((quotation_version_options qvo
     JOIN quotation_versions qv ON ((qvo.quotation_version_id = qv.id)))
     JOIN quotes q ON ((qv.quote_id = q.id)))
  WHERE (q.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.quote_number_config_franchise
ALTER TABLE "public"."quote_number_config_franchise" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise quote config" ON "public"."quote_number_config_franchise"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all franchise quote configs" ON "public"."quote_number_config_franchise"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage franchise quote configs" ON "public"."quote_number_config_franchise"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view franchise quote config" ON "public"."quote_number_config_franchise"
  FOR SELECT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;

-- Enable RLS on public.quote_number_config_tenant
ALTER TABLE "public"."quote_number_config_tenant" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all tenant quote configs" ON "public"."quote_number_config_tenant"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant quote config" ON "public"."quote_number_config_tenant"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant quote config" ON "public"."quote_number_config_tenant"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.quote_number_sequences
ALTER TABLE "public"."quote_number_sequences" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all quote sequences" ON "public"."quote_number_sequences"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "System can manage quote sequences" ON "public"."quote_number_sequences"
  FOR ALL
  TO PUBLIC
  USING (true)
;

-- Enable RLS on public.quote_presentation_templates
ALTER TABLE "public"."quote_presentation_templates" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pt_admin" ON "public"."quote_presentation_templates"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "pt_tenant" ON "public"."quote_presentation_templates"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "pt_view" ON "public"."quote_presentation_templates"
  FOR SELECT
  TO "authenticated"
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.quote_shares
ALTER TABLE "public"."quote_shares" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "qs_admin" ON "public"."quote_shares"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "qs_public" ON "public"."quote_shares"
  FOR SELECT
  TO "anon", "authenticated"
  USING ((is_active = true))
;
CREATE POLICY "qs_user" ON "public"."quote_shares"
  FOR ALL
  TO "authenticated"
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE (quotes.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.quote_templates
ALTER TABLE "public"."quote_templates" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage their tenant templates" ON "public"."quote_templates"
  FOR ALL
  TO PUBLIC
  USING (((tenant_id IN ( SELECT user_roles.tenant_id
   FROM user_roles
  WHERE (user_roles.user_id = auth.uid()))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;
CREATE POLICY "Users can view their tenant templates" ON "public"."quote_templates"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id IN ( SELECT user_roles.tenant_id
   FROM user_roles
  WHERE (user_roles.user_id = auth.uid()))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;

-- Enable RLS on public.quotes
ALTER TABLE "public"."quotes" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise quotes" ON "public"."quotes"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all quotes" ON "public"."quotes"
  FOR ALL
  TO "authenticated"
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant quotes" ON "public"."quotes"
  FOR ALL
  TO "authenticated"
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create franchise quotes" ON "public"."quotes"
  FOR INSERT
  TO "authenticated"
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users can view franchise quotes" ON "public"."quotes"
  FOR SELECT
  TO "authenticated"
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;

-- Enable RLS on public.rate_calculations
ALTER TABLE "public"."rate_calculations" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can create calculations" ON "public"."rate_calculations"
  FOR INSERT
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE ((quotes.franchise_id = get_user_franchise_id(auth.uid())) OR (quotes.owner_id = auth.uid())))))
;
CREATE POLICY "Users can view calculations for accessible quotes" ON "public"."rate_calculations"
  FOR SELECT
  TO PUBLIC
  USING ((quote_id IN ( SELECT quotes.id
   FROM quotes
  WHERE ((quotes.franchise_id = get_user_franchise_id(auth.uid())) OR (quotes.owner_id = auth.uid())))))
;

-- Enable RLS on public.routes
ALTER TABLE "public"."routes" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all routes" ON "public"."routes"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant routes" ON "public"."routes"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant routes" ON "public"."routes"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.scheduled_emails
ALTER TABLE "public"."scheduled_emails" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Scheduled emails scope matrix" ON "public"."scheduled_emails"
  FOR ALL
  TO "authenticated"
  USING ((is_platform_admin(auth.uid()) OR (is_tenant_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid()))) OR (is_franchise_admin(auth.uid()) AND (tenant_id = get_user_tenant_id(auth.uid())) AND (franchise_id = get_user_franchise_id(auth.uid()))) OR (is_sales_manager(auth.uid()) AND (user_id IN ( SELECT get_sales_manager_team_user_ids(auth.uid()) AS get_sales_manager_team_user_ids))) OR (user_id = auth.uid())))
;

-- Enable RLS on public.service_leg_categories
ALTER TABLE "public"."service_leg_categories" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view active service leg categories" ON "public"."service_leg_categories"
  FOR SELECT
  TO PUBLIC
  USING ((is_active = true))
;
CREATE POLICY "Platform admins can manage service leg categories" ON "public"."service_leg_categories"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;

-- Enable RLS on public.service_modes
ALTER TABLE "public"."service_modes" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "service_modes_tenant_read" ON "public"."service_modes"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "service_modes_tenant_write" ON "public"."service_modes"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.service_type_mappings
ALTER TABLE "public"."service_type_mappings" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all mappings" ON "public"."service_type_mappings"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant mappings" ON "public"."service_type_mappings"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant mappings" ON "public"."service_type_mappings"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.service_types
ALTER TABLE "public"."service_types" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view service types" ON "public"."service_types"
  FOR SELECT
  TO PUBLIC
  USING (true)
;
CREATE POLICY "Platform admins can manage all service types" ON "public"."service_types"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;

-- Enable RLS on public.services
ALTER TABLE "public"."services" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all services" ON "public"."services"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage services" ON "public"."services"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Tenant users can view services" ON "public"."services"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.shipment_attachments
ALTER TABLE "public"."shipment_attachments" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can manage their shipment attachments" ON "public"."shipment_attachments"
  FOR ALL
  TO PUBLIC
  USING (((shipment_id IN ( SELECT shipments.id
   FROM shipments
  WHERE (shipments.tenant_id IN ( SELECT user_roles.tenant_id
           FROM user_roles
          WHERE (user_roles.user_id = auth.uid()))))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;
CREATE POLICY "Users can view their shipment attachments" ON "public"."shipment_attachments"
  FOR SELECT
  TO PUBLIC
  USING (((shipment_id IN ( SELECT shipments.id
   FROM shipments
  WHERE (shipments.tenant_id IN ( SELECT user_roles.tenant_id
           FROM user_roles
          WHERE (user_roles.user_id = auth.uid()))))) OR (EXISTS ( SELECT 1
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = 'platform_admin'::app_role))))))
;

-- Enable RLS on public.shipment_items
ALTER TABLE "public"."shipment_items" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all shipment items" ON "public"."shipment_items"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can manage items for accessible shipments" ON "public"."shipment_items"
  FOR ALL
  TO PUBLIC
  USING ((shipment_id IN ( SELECT shipments.id
   FROM shipments
  WHERE ((shipments.franchise_id = get_user_franchise_id(auth.uid())) OR (shipments.assigned_to = auth.uid())))))
;

-- Enable RLS on public.shipments
ALTER TABLE "public"."shipments" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise shipments" ON "public"."shipments"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all shipments" ON "public"."shipments"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant shipments" ON "public"."shipments"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can create franchise shipments" ON "public"."shipments"
  FOR INSERT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Users can view assigned shipments" ON "public"."shipments"
  FOR SELECT
  TO PUBLIC
  USING (((assigned_to = auth.uid()) OR (franchise_id = get_user_franchise_id(auth.uid()))))
;

-- Enable RLS on public.shipping_rates
ALTER TABLE "public"."shipping_rates" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all shipping rates" ON "public"."shipping_rates"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant shipping rates" ON "public"."shipping_rates"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view tenant shipping rates" ON "public"."shipping_rates"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.states
ALTER TABLE "public"."states" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "states_manage" ON "public"."states"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "states_read" ON "public"."states"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id IS NULL) OR (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.subscription_features
ALTER TABLE "public"."subscription_features" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view subscription features" ON "public"."subscription_features"
  FOR SELECT
  TO PUBLIC
  USING (true)
;
CREATE POLICY "Platform admins can manage subscription features" ON "public"."subscription_features"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;

-- Enable RLS on public.subscription_invoices
ALTER TABLE "public"."subscription_invoices" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all invoices" ON "public"."subscription_invoices"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can view own invoices" ON "public"."subscription_invoices"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.subscription_plans
ALTER TABLE "public"."subscription_plans" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view active subscription plans" ON "public"."subscription_plans"
  FOR SELECT
  TO PUBLIC
  USING ((is_active = true))
;
CREATE POLICY "Platform admins can manage subscription plans" ON "public"."subscription_plans"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;

-- Enable RLS on public.tenant_subscriptions
ALTER TABLE "public"."tenant_subscriptions" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all subscriptions" ON "public"."tenant_subscriptions"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can update own subscriptions" ON "public"."tenant_subscriptions"
  FOR UPDATE
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Tenant admins can view own subscriptions" ON "public"."tenant_subscriptions"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.tenants
ALTER TABLE "public"."tenants" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins full access to tenants" ON "public"."tenants"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can update own tenant" ON "public"."tenants"
  FOR UPDATE
  TO PUBLIC
  USING ((id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "Tenant admins can view own tenant" ON "public"."tenants"
  FOR SELECT
  TO PUBLIC
  USING ((id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.territories
ALTER TABLE "public"."territories" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all territories" ON "public"."territories"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant territories" ON "public"."territories"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.territory_assignments
ALTER TABLE "public"."territory_assignments" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all territory assignments" ON "public"."territory_assignments"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage territory assignments" ON "public"."territory_assignments"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (territory_id IN ( SELECT territories.id
   FROM territories
  WHERE (territories.tenant_id = get_user_tenant_id(auth.uid()))))))
;

-- Enable RLS on public.territory_geographies
ALTER TABLE "public"."territory_geographies" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Territory geographies deletable" ON "public"."territory_geographies"
  FOR DELETE
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM (user_roles ur
     JOIN territories t ON ((t.id = territory_geographies.territory_id)))
  WHERE ((ur.user_id = auth.uid()) AND ((ur.role = 'platform_admin'::app_role) OR (ur.tenant_id = t.tenant_id))))))
;
CREATE POLICY "Territory geographies insertable" ON "public"."territory_geographies"
  FOR INSERT
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM (user_roles ur
     JOIN territories t ON ((t.id = territory_geographies.territory_id)))
  WHERE ((ur.user_id = auth.uid()) AND ((ur.role = 'platform_admin'::app_role) OR (ur.tenant_id = t.tenant_id))))))
;
CREATE POLICY "Territory geographies readable" ON "public"."territory_geographies"
  FOR SELECT
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM (user_roles ur
     JOIN territories t ON ((t.id = territory_geographies.territory_id)))
  WHERE ((ur.user_id = auth.uid()) AND ((ur.role = 'platform_admin'::app_role) OR (ur.tenant_id = t.tenant_id))))))
;
CREATE POLICY "Territory geographies updatable" ON "public"."territory_geographies"
  FOR UPDATE
  TO PUBLIC
  USING ((EXISTS ( SELECT 1
   FROM (user_roles ur
     JOIN territories t ON ((t.id = territory_geographies.territory_id)))
  WHERE ((ur.user_id = auth.uid()) AND ((ur.role = 'platform_admin'::app_role) OR (ur.tenant_id = t.tenant_id))))))
;

-- Enable RLS on public.themes
ALTER TABLE "public"."themes" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Tenant admins can manage themes" ON "public"."themes"
  FOR ALL
  TO PUBLIC
  USING (((tenant_id IN ( SELECT user_roles.tenant_id
   FROM user_roles
  WHERE ((user_roles.user_id = auth.uid()) AND (user_roles.role = ANY (ARRAY['tenant_admin'::app_role, 'platform_admin'::app_role]))))) OR is_platform_admin(auth.uid())))
;
CREATE POLICY "Users can view themes in their tenant" ON "public"."themes"
  FOR SELECT
  TO PUBLIC
  USING (((tenant_id IN ( SELECT user_roles.tenant_id
   FROM user_roles
  WHERE (user_roles.user_id = auth.uid()))) OR is_platform_admin(auth.uid())))
;

-- Enable RLS on public.tracking_events
ALTER TABLE "public"."tracking_events" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all tracking events" ON "public"."tracking_events"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Users can create tracking events for accessible shipments" ON "public"."tracking_events"
  FOR INSERT
  TO PUBLIC
  USING ((shipment_id IN ( SELECT shipments.id
   FROM shipments
  WHERE ((shipments.franchise_id = get_user_franchise_id(auth.uid())) OR (shipments.assigned_to = auth.uid())))))
;
CREATE POLICY "Users can view tracking for accessible shipments" ON "public"."tracking_events"
  FOR SELECT
  TO PUBLIC
  USING ((shipment_id IN ( SELECT shipments.id
   FROM shipments
  WHERE ((shipments.franchise_id = get_user_franchise_id(auth.uid())) OR (shipments.assigned_to = auth.uid())))))
;

-- Enable RLS on public.trade_directions
ALTER TABLE "public"."trade_directions" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "trade_directions_tenant_read" ON "public"."trade_directions"
  FOR SELECT
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;
CREATE POLICY "trade_directions_tenant_write" ON "public"."trade_directions"
  FOR ALL
  TO PUBLIC
  USING ((tenant_id = get_user_tenant_id(auth.uid())))
;

-- Enable RLS on public.transport_modes
ALTER TABLE "public"."transport_modes" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can view active transport modes" ON "public"."transport_modes"
  FOR SELECT
  TO PUBLIC
  USING ((is_active = true))
;
CREATE POLICY "Platform admins can manage transport modes" ON "public"."transport_modes"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;

-- Enable RLS on public.usage_records
ALTER TABLE "public"."usage_records" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all usage records" ON "public"."usage_records"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can view own usage records" ON "public"."usage_records"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.user_capacity
ALTER TABLE "public"."user_capacity" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all user capacity" ON "public"."user_capacity"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant user capacity" ON "public"."user_capacity"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view own capacity" ON "public"."user_capacity"
  FOR SELECT
  TO PUBLIC
  USING ((user_id = auth.uid()))
;

-- Enable RLS on public.user_custom_roles
ALTER TABLE "public"."user_custom_roles" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can manage franchise user custom roles" ON "public"."user_custom_roles"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can manage all user custom roles" ON "public"."user_custom_roles"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant user custom roles" ON "public"."user_custom_roles"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view own custom roles" ON "public"."user_custom_roles"
  FOR SELECT
  TO PUBLIC
  USING ((user_id = auth.uid()))
;

-- Enable RLS on public.user_preferences
ALTER TABLE "public"."user_preferences" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can delete their own preferences" ON "public"."user_preferences"
  FOR DELETE
  TO "authenticated"
  USING ((auth.uid() = user_id))
;
CREATE POLICY "Users can insert their own preferences" ON "public"."user_preferences"
  FOR INSERT
  TO "authenticated"
  USING ((auth.uid() = user_id))
;
CREATE POLICY "Users can update their own preferences" ON "public"."user_preferences"
  FOR UPDATE
  TO "authenticated"
  USING ((auth.uid() = user_id))
;
CREATE POLICY "Users can view their own preferences" ON "public"."user_preferences"
  FOR SELECT
  TO "authenticated"
  USING ((auth.uid() = user_id))
;

-- Enable RLS on public.user_roles
ALTER TABLE "public"."user_roles" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise admins can update franchise user roles" ON "public"."user_roles"
  FOR UPDATE
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Franchise admins can view franchise roles" ON "public"."user_roles"
  FOR SELECT
  TO PUBLIC
  USING ((has_role(auth.uid(), 'franchise_admin'::app_role) AND (franchise_id = get_user_franchise_id(auth.uid()))))
;
CREATE POLICY "Platform admins can update user roles" ON "public"."user_roles"
  FOR UPDATE
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Platform admins full access to roles" ON "public"."user_roles"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant roles" ON "public"."user_roles"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Tenant admins can update tenant user roles" ON "public"."user_roles"
  FOR UPDATE
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
CREATE POLICY "Users can view own roles" ON "public"."user_roles"
  FOR SELECT
  TO PUBLIC
  USING ((user_id = auth.uid()))
;

-- Enable RLS on public.vehicles
ALTER TABLE "public"."vehicles" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise users can view franchise vehicles" ON "public"."vehicles"
  FOR SELECT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Platform admins can manage all vehicles" ON "public"."vehicles"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant vehicles" ON "public"."vehicles"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;

-- Enable RLS on public.warehouse_inventory
ALTER TABLE "public"."warehouse_inventory" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Platform admins can manage all warehouse inventory" ON "public"."warehouse_inventory"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant warehouse inventory" ON "public"."warehouse_inventory"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (warehouse_id IN ( SELECT warehouses.id
   FROM warehouses
  WHERE (warehouses.tenant_id = get_user_tenant_id(auth.uid()))))))
;
CREATE POLICY "Users can view franchise warehouse inventory" ON "public"."warehouse_inventory"
  FOR SELECT
  TO PUBLIC
  USING ((warehouse_id IN ( SELECT warehouses.id
   FROM warehouses
  WHERE (warehouses.franchise_id = get_user_franchise_id(auth.uid())))))
;

-- Enable RLS on public.warehouses
ALTER TABLE "public"."warehouses" ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Franchise users can view franchise warehouses" ON "public"."warehouses"
  FOR SELECT
  TO PUBLIC
  USING ((franchise_id = get_user_franchise_id(auth.uid())))
;
CREATE POLICY "Platform admins can manage all warehouses" ON "public"."warehouses"
  FOR ALL
  TO PUBLIC
  USING (is_platform_admin(auth.uid()))
;
CREATE POLICY "Tenant admins can manage tenant warehouses" ON "public"."warehouses"
  FOR ALL
  TO PUBLIC
  USING ((has_role(auth.uid(), 'tenant_admin'::app_role) AND (tenant_id = get_user_tenant_id(auth.uid()))))
;
