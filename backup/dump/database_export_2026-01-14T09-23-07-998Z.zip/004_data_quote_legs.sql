-- 004_data_quote_legs.sql
-- Table Data for quote_legs

INSERT INTO "public"."quote_legs" ("id", "tenant_id", "quote_option_id", "leg_number", "mode", "service_type_id", "origin_location", "destination_location", "carrier_id", "transit_days", "departure_date", "arrival_date", "notes", "sort_order", "created_at", "updated_at") VALUES ('07868676-898a-47af-841f-1508f72e5276', '9e2686ba-ef3c-42df-aea6-dcc880436b9f', 'ee3b87d0-5d8f-4e48-afe0-4e2538e37c67', 1, 'ocean', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1000, '2025-11-17T05:14:59.660676+00:00', '2025-11-17T05:14:59.660676+00:00');
