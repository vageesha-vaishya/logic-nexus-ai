-- 004_data_tenant_subscriptions.sql
-- Table Data for tenant_subscriptions

INSERT INTO "public"."tenant_subscriptions" ("id", "tenant_id", "plan_id", "status", "stripe_subscription_id", "stripe_customer_id", "current_period_start", "current_period_end", "trial_end", "canceled_at", "ended_at", "auto_renew", "metadata", "created_at", "updated_at") VALUES ('39ee6524-47c5-47fe-b90c-af8333e79067', '9e2686ba-ef3c-42df-aea6-dcc880436b9f', '4377419a-01b3-43ff-9ae9-b8418242e3de', 'active', NULL, NULL, '2025-10-06T13:57:15.487+00:00', '2025-11-05T13:57:15.487+00:00', NULL, NULL, NULL, TRUE, '{}', '2025-10-06T13:57:15.830654+00:00', '2025-10-06T13:57:15.830654+00:00');
