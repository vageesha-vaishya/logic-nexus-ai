-- 004_data_queue_members.sql
-- Table Data for queue_members

INSERT INTO "public"."queue_members" ("id", "queue_id", "user_id", "created_at", "tenant_id") VALUES ('42b2403a-3510-4ac0-b497-39609a5f3617', '17c85d44-4d7c-4294-8f7c-2a6ea01298af', '61cc7bda-7710-4cb7-9c4d-9c05122645c9', '2026-01-06T03:12:56.37125+00:00', NULL);
