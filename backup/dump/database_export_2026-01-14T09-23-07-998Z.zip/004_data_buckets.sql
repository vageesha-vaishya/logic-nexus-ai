-- 004_data_buckets.sql
-- Table Data for buckets

INSERT INTO "storage"."buckets" ("id", "name", "type", "owner", "public", "owner_id", "created_at", "updated_at", "file_size_limit", "allowed_mime_types", "avif_autodetection") VALUES ('db-backups', 'db-backups', 'STANDARD', NULL, FALSE, NULL, '2025-10-24T11:41:21.833454+00:00', '2025-10-24T11:41:21.833454+00:00', NULL, NULL, FALSE);
INSERT INTO "storage"."buckets" ("id", "name", "type", "owner", "public", "owner_id", "created_at", "updated_at", "file_size_limit", "allowed_mime_types", "avif_autodetection") VALUES ('soslogistics', 'soslogistics', 'STANDARD', NULL, FALSE, NULL, '2026-01-13T13:41:03.949301+00:00', '2026-01-13T13:41:03.949301+00:00', NULL, NULL, FALSE);
