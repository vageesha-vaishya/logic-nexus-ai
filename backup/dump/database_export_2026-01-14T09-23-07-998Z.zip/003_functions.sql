-- 003_functions.sql
-- Database Functions

-- Function metadata: public.assign_email_to_queue (definition unavailable)

-- Function metadata: public.assign_franchisee_account_contact (definition unavailable)

-- Function metadata: public.auto_assign_version_number (definition unavailable)

-- Function metadata: public.auto_generate_quote_number (definition unavailable)

-- Function metadata: public.calculate_dimensional_weight (definition unavailable)

-- Function metadata: public.calculate_lead_score (definition unavailable)

-- Function metadata: public.calculate_next_version_number (definition unavailable)

-- Function metadata: public.calculate_option_margins (definition unavailable)

-- Function metadata: public.calculate_option_totals (definition unavailable)

-- Function metadata: public.check_usage_limit (definition unavailable)

-- Function metadata: public.compare_versions (definition unavailable)

-- Function metadata: public.create_quote_share (definition unavailable)

-- Function metadata: public.decrement_user_lead_count (definition unavailable)

-- Function metadata: public.evaluate_provider_rate_rules (definition unavailable)

-- Function metadata: public.execute_sql_query (definition unavailable)

-- Function metadata: public.execute_transfer (definition unavailable)

-- Function metadata: public.generate_next_option_name (definition unavailable)

-- Function metadata: public.generate_quote_number (definition unavailable)

-- Function metadata: public.generate_share_token (definition unavailable)

-- Function metadata: public.get_all_database_schema (definition unavailable)

-- Function metadata: public.get_all_database_tables (definition unavailable)

-- Function metadata: public.get_applicable_provider_surcharges (definition unavailable)

-- Function metadata: public.get_auth_users_export (definition unavailable)

-- Function metadata: public.get_chargeable_weight (definition unavailable)

-- Function metadata: public.get_database_enums (definition unavailable)

-- Function metadata: public.get_database_functions (definition unavailable)

-- Function metadata: public.get_database_schema (definition unavailable)

-- Function metadata: public.get_database_tables (definition unavailable)

-- Function metadata: public.get_delegated_email_account_ids (definition unavailable)

-- Function metadata: public.get_franchise_user_ids (definition unavailable)

-- Function metadata: public.get_platform_admins (definition unavailable)

-- Function metadata: public.get_queue_counts (definition unavailable)

-- Function metadata: public.get_rls_policies (definition unavailable)

-- Function metadata: public.get_rls_status (definition unavailable)

-- Function metadata: public.get_sales_manager_team_user_ids (definition unavailable)

-- Function metadata: public.get_storage_objects_export (definition unavailable)

-- Function metadata: public.get_table_constraints (definition unavailable)

-- Function metadata: public.get_table_count (definition unavailable)

-- Function metadata: public.get_table_data_dynamic (definition unavailable)

-- Function metadata: public.get_table_indexes (definition unavailable)

-- Function metadata: public.get_tenant_plan_tier (definition unavailable)

-- Function metadata: public.get_tier_rate (definition unavailable)

-- Function metadata: public.get_user_custom_permissions (definition unavailable)

-- Function metadata: public.get_user_email_account_ids (definition unavailable)

-- Function metadata: public.get_user_franchise_id (definition unavailable)

-- Function metadata: public.get_user_queues (definition unavailable)

-- Function metadata: public.get_user_tenant_id (definition unavailable)

-- Function metadata: public.get_weight_break_rate (definition unavailable)

-- Function metadata: public.handle_new_user (definition unavailable)

-- Function metadata: public.has_role (definition unavailable)

-- Function metadata: public.increment_feature_usage (definition unavailable)

-- Function metadata: public.increment_user_lead_count (definition unavailable)

-- Function metadata: public.is_current_user_platform_admin (definition unavailable)

-- Function metadata: public.is_franchise_admin (definition unavailable)

-- Function metadata: public.is_platform_admin (definition unavailable)

-- Function metadata: public.is_sales_manager (definition unavailable)

-- Function metadata: public.is_super_admin (definition unavailable)

-- Function metadata: public.is_tenant_admin (definition unavailable)

-- Function metadata: public.is_viewer (definition unavailable)

-- Function metadata: public.log_email_audit (definition unavailable)

-- Function metadata: public.log_option_changes (definition unavailable)

-- Function metadata: public.log_version_changes (definition unavailable)

-- Function metadata: public.preview_next_quote_number (definition unavailable)

-- Function metadata: public.process_email_queue_assignment (definition unavailable)

-- Function metadata: public.record_customer_selection (definition unavailable)

-- Function metadata: public.reload_postgrest_schema (definition unavailable)

-- Function metadata: public.set_admin_override (definition unavailable)

-- Function metadata: public.set_current_version (definition unavailable)

-- Function metadata: public.set_user_scope_preference (definition unavailable)

-- Function metadata: public.tenant_has_feature (definition unavailable)

-- Function metadata: public.update_lead_score (definition unavailable)

-- Function metadata: public.update_option_margins_on_charge_change (definition unavailable)

-- Function metadata: public.update_option_totals (definition unavailable)

-- Function metadata: public.update_queue_rules_updated_at (definition unavailable)

-- Function metadata: public.update_scheduled_email_timestamp (definition unavailable)

-- Function metadata: public.update_updated_at_column (definition unavailable)

-- Function metadata: public.validate_leg_sort_order (definition unavailable)

-- Function metadata: public.validate_service_leg_requirements (definition unavailable)

-- Function metadata: public.validate_single_selection_per_version (definition unavailable)

-- Function metadata: public.validate_version_status_transition (definition unavailable)

-- Function metadata: public.validate_version_uniqueness (definition unavailable)

