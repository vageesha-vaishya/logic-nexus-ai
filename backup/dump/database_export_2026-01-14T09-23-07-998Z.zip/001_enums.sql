-- 001_enums.sql
-- Database Enums and Types

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'account_status') THEN
        CREATE TYPE "account_status" AS ENUM ('active', 'inactive', 'pending');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'account_type') THEN
        CREATE TYPE "account_type" AS ENUM ('prospect', 'customer', 'partner', 'vendor');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'activity_status') THEN
        CREATE TYPE "activity_status" AS ENUM ('planned', 'in_progress', 'completed', 'cancelled');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'activity_type') THEN
        CREATE TYPE "activity_type" AS ENUM ('call', 'email', 'meeting', 'task', 'note');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'app_role') THEN
        CREATE TYPE "app_role" AS ENUM ('platform_admin', 'tenant_admin', 'franchise_admin', 'user', 'sales_manager', 'viewer');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'billing_period') THEN
        CREATE TYPE "billing_period" AS ENUM ('monthly', 'annual');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'container_type') THEN
        CREATE TYPE "container_type" AS ENUM ('20ft_standard', '40ft_standard', '40ft_high_cube', '45ft_high_cube', 'reefer', 'open_top', 'flat_rack', 'tank');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'lead_source') THEN
        CREATE TYPE "lead_source" AS ENUM ('website', 'referral', 'email', 'phone', 'social', 'event', 'other');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'lead_status') THEN
        CREATE TYPE "lead_status" AS ENUM ('new', 'contacted', 'qualified', 'proposal', 'negotiation', 'won', 'lost', 'converted');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'opportunity_stage') THEN
        CREATE TYPE "opportunity_stage" AS ENUM ('prospecting', 'qualification', 'needs_analysis', 'value_proposition', 'proposal', 'negotiation', 'closed_won', 'closed_lost');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'plan_type') THEN
        CREATE TYPE "plan_type" AS ENUM ('crm_base', 'service_addon', 'bundle');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'priority_level') THEN
        CREATE TYPE "priority_level" AS ENUM ('low', 'medium', 'high', 'urgent');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'quote_reset_policy') THEN
        CREATE TYPE "quote_reset_policy" AS ENUM ('none', 'daily', 'monthly', 'yearly');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'shipment_status') THEN
        CREATE TYPE "shipment_status" AS ENUM ('draft', 'confirmed', 'in_transit', 'customs', 'out_for_delivery', 'delivered', 'cancelled', 'on_hold', 'returned');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'shipment_type') THEN
        CREATE TYPE "shipment_type" AS ENUM ('ocean_freight', 'air_freight', 'inland_trucking', 'railway_transport', 'courier', 'movers_packers');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'subscription_status') THEN
        CREATE TYPE "subscription_status" AS ENUM ('active', 'trial', 'past_due', 'canceled', 'expired');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'subscription_tier') THEN
        CREATE TYPE "subscription_tier" AS ENUM ('starter', 'professional', 'business', 'enterprise');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'tracking_event_type') THEN
        CREATE TYPE "tracking_event_type" AS ENUM ('created', 'confirmed', 'picked_up', 'in_transit', 'customs_clearance', 'customs_released', 'arrived_at_hub', 'out_for_delivery', 'delivered', 'delayed', 'exception', 'returned');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'transfer_entity_type') THEN
        CREATE TYPE "transfer_entity_type" AS ENUM ('lead', 'opportunity', 'quote', 'shipment', 'account', 'contact', 'activity');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'transfer_status') THEN
        CREATE TYPE "transfer_status" AS ENUM ('pending', 'approved', 'rejected', 'completed', 'failed');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'transfer_type') THEN
        CREATE TYPE "transfer_type" AS ENUM ('tenant_to_tenant', 'tenant_to_franchise', 'franchise_to_franchise');
    END IF;
END $$;

DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'vehicle_status') THEN
        CREATE TYPE "vehicle_status" AS ENUM ('available', 'in_use', 'maintenance', 'out_of_service');
    END IF;
END $$;

