-- 004_data_user_capacity.sql
-- Table Data for user_capacity

INSERT INTO "public"."user_capacity" ("id", "user_id", "tenant_id", "franchise_id", "max_leads", "current_leads", "is_available", "last_assigned_at", "created_at", "updated_at") VALUES ('d138f18d-e81d-4508-b976-dbd95d874fc4', '61cc7bda-7710-4cb7-9c4d-9c05122645c9', '37a4d9ca-626d-4ed3-9e71-5d416e7ccaf8', NULL, 50, 0, TRUE, '2025-10-04T05:15:57.425671+00:00', '2025-10-04T05:15:57.425671+00:00', '2025-10-04T05:49:40.944597+00:00');
INSERT INTO "public"."user_capacity" ("id", "user_id", "tenant_id", "franchise_id", "max_leads", "current_leads", "is_available", "last_assigned_at", "created_at", "updated_at") VALUES ('4d39bd71-9e66-439a-943b-2b5533c0b2fc', 'ce4c64f5-cd8c-4d2d-bbbd-04972c4a7768', '37a4d9ca-626d-4ed3-9e71-5d416e7ccaf8', NULL, 50, 2, TRUE, '2025-10-04T11:11:29.345413+00:00', '2025-10-04T05:49:41.14486+00:00', '2025-10-04T11:11:29.345413+00:00');
