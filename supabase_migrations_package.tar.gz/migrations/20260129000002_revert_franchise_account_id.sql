ALTER TABLE public.franchises DROP COLUMN IF EXISTS account_id;
