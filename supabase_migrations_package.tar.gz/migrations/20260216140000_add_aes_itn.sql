ALTER TABLE public.shipments ADD COLUMN IF NOT EXISTS aes_itn TEXT;
