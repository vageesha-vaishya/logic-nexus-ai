-- Force types regeneration
COMMENT ON TABLE tenants IS 'Tenant organizations in the system';